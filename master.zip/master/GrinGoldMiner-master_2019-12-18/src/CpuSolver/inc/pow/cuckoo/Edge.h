#ifndef _EDGE_H_
#define _EDGE_H_
#include "cuckoo.h"
#include <string>
#include <sstream>

using namespace std;
namespace tensorchip
{
class Edge
{
public:
  Edge() : u(0), v(0) {}
  Edge(word_t x, word_t y) : u(x), v(y) {}

  word_t u, v;

  string toString()
  {
    stringstream ss;
    ss << fixed << "Edge \t: ( " << u << " -> " << v << " )" << endl;
    return ss.str();
  }
};
};

#endif
