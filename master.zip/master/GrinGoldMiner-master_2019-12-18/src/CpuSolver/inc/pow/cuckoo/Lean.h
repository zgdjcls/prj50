#ifndef _LEAN_H_
#define _LEAN_H_

#include "Pow.h"
#include <unistd.h>
#include "cuckoo/cuckoo.h"
#include "crypto/siphashxN.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "threads/barrier.h"
#include <assert.h>
#include <set>
#include "common/Memory.h"

typedef uint64_t u64; // save some typing
typedef u32 au32;
typedef u64 au64;

#ifndef SIZEOF_TWICE_ATOM
#define SIZEOF_TWICE_ATOM 4
#endif
#if SIZEOF_TWICE_ATOM == 8
typedef au64 atwice;
typedef u64 uatwice;
#elif SIZEOF_TWICE_ATOM == 4
typedef au32 atwice;
typedef u32 uatwice;
#elif SIZEOF_TWICE_ATOM == 1
typedef unsigned char atwice;
typedef unsigned char uatwice;
#else
#error not implemented
#endif

#define MAX_REMAINS_BITS 20
#define MAX_REMAINS (1<<MAX_REMAINS_BITS)
#define MAXSOLS 8

const int BPW = 8 * SIZEOF_TWICE_ATOM;
const u32 NODEBITS = EDGEBITS + 1;
const word_t NODEMASK = (EDGEMASK << 1) | (word_t)1;

#ifndef PART_BITS
#define PART_BITS 0
#endif

#ifndef NPREFETCH
#define NPREFETCH 32
#endif

#ifndef IDXSHIFT
#define IDXSHIFT (PART_BITS + 6)//6
#endif
// grow with cube root of size, hardly affected by trimming
const u32 LMAXPATHLEN = 8 << (NODEBITS / 3);
const u32 PART_MASK = (1 << PART_BITS) - 1;
const u64 ONCE_BITS = NEDGES >> PART_BITS;
const u64 TWICE_BYTES = (2 * ONCE_BITS) / 8;
const u64 TWICE_ATOMS = TWICE_BYTES / sizeof(atwice);
const u32 TWICE_PER_ATOM = sizeof(atwice) * 4;

const u64 CUCKOO_SIZE = NEDGES >> (IDXSHIFT - 1);
const u64 CUCKOO_MASK = CUCKOO_SIZE - 1;
// number of (least significant) key bits that survives leftshift by NODEBITS
const u32 KEYBITS = 64 - NODEBITS;
const u64 KEYMASK = (1LL << KEYBITS) - 1;
const u64 MAXDRIFT = 1LL << (KEYBITS - IDXSHIFT);

namespace tensorchip
{

class twice_set
{
public:
  Memory<atwice, BPW>* bits = nullptr;

  twice_set();
  void clear();
  void set(word_t u);
  bool test(word_t u) const;
  ~twice_set();
};

class shrinkingset
{
public:
  Memory<u64, 64>* bits = nullptr;
  u64* cnt;
  u32 nthreads;

  shrinkingset(const u32 nt);
  ~shrinkingset();
  void clear();
  u64 count() const;
  void reset(word_t n, u32 thread);
  bool test(word_t n) const;
  u64 block(word_t n) const;
};

class cuckoo_hash
{
public:
  Memory<au64, 64>* cuckoo = nullptr;

  cuckoo_hash(void* recycle);
  void set(word_t u, word_t v);
  word_t operator[](word_t u) const;
};

class cuckoo_ctx
{
public:
  siphash_keys sip_keys;
  shrinkingset* alive;
  twice_set* nonleaf;
  cuckoo_hash* cuckoo;
  word_t (*sols)[PROOFSIZE];
  u32 nonce;
  u32 maxsols;
  au32 nsols;
  u32 nthreads;
  trim_barrier barry;

  cuckoo_ctx(u32 n_threads, u32 max_sols);
  void setheadernonce(char* headernonce, const u32 len, const u32 nce);
  ~cuckoo_ctx();
  void barrier();
  void abort();
  void node_deg(const u64* hashes, const u32 nsiphash, const u32 part) const;
  void count_node_deg(const u32 id, const u32 uorv, const u32 part);
  void kill(const u64* hashes, const u64* indices, const u32 nsiphash, const u32 part, const u32 id) const;
  void kill_leaf_edges(const u32 id, const u32 uorv, const u32 part);
  void solution(word_t* us, u32 nu, word_t* vs, u32 nv);
};

typedef struct
{
  u32 id;
  pthread_t thread;
  cuckoo_ctx* ctx;
} thread_ctx;

extern u32 path(cuckoo_hash& cuckoo, word_t u, word_t* us);
extern void* worker(void* vp);

class Lean : public Pow
{
private:
  int nthreads = 1;
  // int ntrims = 2 + (PART_BITS + 3) * (PART_BITS + 4);
  thread_ctx* threads;
  cuckoo_ctx* ctx;
public:
  Lean(char* header, int eacipct = 50);
  ~Lean();
  void reset(u32 nonce);
  void graph();
  void cycle();
  void report();
};
};

#endif
