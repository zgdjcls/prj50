/*
 * GnssGlobal.h
 *
 *  Created on: Oct 8, 2018
 *      Author: ycgeng
 */

#ifndef LOG_H_
#define LOG_H_


#include <stdio.h>
#include <string.h>
#include <cstdlib>

enum LogLevel
{
  LOG_UNKNOWN = 0,
  LOG_DEFAULT,
  LOG_VERBOSE,
  LOG_DEBUG,
  LOG_INFO,
  LOG_WARN,
  LOG_ERROR,
  LOG_FATAL,
  LOG_SILENT
};

#define TAG PRJ_NAME
#ifdef DEBUG
#define LOG_LEVEL LOG_DEBUG
#else
#define LOG_LEVEL LOG_INFO
#endif

static const char* LogMessage[]
{
  "U",
  "O",
  "V",
  "D",
  "I",
  "W",
  "E",
  "F"
};

static char* space(int n)
{
  char* tab;
  tab = (char*)std::malloc(n + 4);

  if (tab == NULL)
    return NULL;

  tab[0] = '\n';

  for (int i = 0; i < n; i++)
    tab[i + 1] = ' ';

  tab[n + 1] = '|';
  tab[n + 2] = ' ';
  tab[n + 3] = '\0';
  return tab;
}

static char* str_replace(const char* s, const char* oldW,
                         const char* newW)
{
  char* result;
  int i, cnt = 0;
  int newWlen = strlen(newW);
  int oldWlen = strlen(oldW);

  // Counting the number of times old word
  // occur in the string
  for (i = 0; s[i] != '\0'; i++)
    {
      if (strstr(&s[i], oldW) == &s[i])
        {
          cnt++;
          // Jumping to index after the old word.
          i += oldWlen - 1;
        }
    }

  // Making new string of enough length
  result = (char*)std::malloc(i + cnt * (newWlen - oldWlen) + 1);
  i = 0;

  while (*s)
    {
      // compare the substring with the result
      if ((strstr(s, oldW)) == s)
        {
          strcpy(&result[i], newW);
          i += newWlen;
          s += oldWlen;
        }
      else
        result[i++] = *s++;
    }

  result[i] = '\0';
  return result;
}

static const int LOG_TAB_SIZE = sizeof(TAG) + 1;
static const char LF[] = "\n";
static const char* LOG_TAB = space(LOG_TAB_SIZE);
static const int LOG_BUF_SIZE = 1024;



#define _LOG(prio,tag,format,...) {\
    if((int)prio >= static_cast<int>(LOG_LEVEL)) {  \
      char buf[LOG_BUF_SIZE]; \
      sprintf(buf,"%s",LogMessage[(int)prio]);       \
      sprintf(buf+strlen(LogMessage[(int)prio]),"/" tag "| " format,## __VA_ARGS__);  \
      char *indent = str_replace(buf,LF,LOG_TAB);   \
      printf("%s\n",indent);        \
      free(indent);         \
    }\
    if(prio == LOG_FATAL)\
      ::exit(1); \
  }

#define LOG_D(format,...) _LOG(LOG_DEBUG,TAG,format,## __VA_ARGS__)
#define LOG_I(format,...) _LOG(LOG_INFO,TAG,format,## __VA_ARGS__)
#define LOG_W(format,...) _LOG(LOG_WARN,TAG,format,##__VA_ARGS__)
#define LOG_E(format,...) _LOG(LOG_ERROR,TAG,format,## __VA_ARGS__)
#define LOG_F(format,...) _LOG(LOG_FATAL,TAG,format,## __VA_ARGS__)
#define LOG(format,...) _LOG(LOG_LEVEL,TAG,format, ## __VA_ARGS__)
#define LOG_LOCATION LOG("%s#%d\n",__FUNCTION__,__LINE__)

#endif /* LOG_H_ */
