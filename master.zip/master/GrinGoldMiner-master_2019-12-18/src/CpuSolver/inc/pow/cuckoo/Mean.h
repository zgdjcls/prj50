#ifndef MEAN_H
#define MEAN_H

#include "cuckoo/cuckoo.h"
#include "crypto/siphashxN.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <x86intrin.h>
#include <assert.h>
#include <vector>
#include <bitset>
#include "threads/barrier.h"
#include "Pow.h"

namespace tensorchip
{

#ifndef XBITS
#if EDGEBITS <= 19
#define XBITS 2
#else
#define XBITS 11
#endif
#endif

#define YBITS XBITS

// size in bytes of a big bucket entry
#ifndef BIGSIZE
#if EDGEBITS <= 15
#define BIGSIZE 4
// no compression needed
#define COMPRESSROUND 0
#else
#define BIGSIZE 5
// YZ compression round; must be even
#ifndef COMPRESSROUND
#define COMPRESSROUND 14
#endif
#endif
#endif
// size in bytes of a small bucket entry
#define SMALLSIZE BIGSIZE

// initial entries could be smaller at percent or two slowdown
#ifndef BIGSIZE0
#if EDGEBITS < 30 && !defined SAVEEDGES
#define BIGSIZE0 4
#else
#define BIGSIZE0 BIGSIZE
#endif
#endif
// but they may need syncing entries
#if BIGSIZE0 == 4 && EDGEBITS > 27
#define NEEDSYNC
#endif

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

#if EDGEBITS >= 30
typedef u64 offset_t;
#else
typedef u32 offset_t;
#endif

#if BIGSIZE0 > 4
typedef u64 BIGTYPE0;
#else
typedef u32 BIGTYPE0;
#endif

// node bits have two groups of bucketbits (X for big and Y for small) and a remaining group Z of degree bits
const u32 NX        = 1 << XBITS;
const u32 XMASK     = NX - 1;
const u32 NY        = 1 << YBITS;
const u32 YMASK     = NY - 1;
const u32 XYBITS    = XBITS + YBITS;
const u32 NXY       = 1 << XYBITS;
const u32 ZBITS     = EDGEBITS - XYBITS;
const u32 NZ        = 1 << ZBITS;
const u32 ZMASK     = NZ - 1;
const u32 YZBITS    = EDGEBITS - XBITS;
const u32 NYZ       = 1 << YZBITS;
const u32 YZMASK    = NYZ - 1;
const u32 YZ1BITS   = YZBITS < 15 ? YZBITS : 12;  // compressed YZ bits
const u32 NYZ1      = 1 << YZ1BITS;
const u32 MAXNZNYZ1 = NYZ1 < NZ ? NZ : NYZ1;
const u32 YZ1MASK   = NYZ1 - 1;
const u32 Z1BITS    = YZ1BITS - YBITS;
const u32 NZ1       = 1 << Z1BITS;
const u32 Z1MASK    = NZ1 - 1;
const u32 YZ2BITS   = YZBITS < 11 ? YZBITS : 12;  // more compressed YZ bits
const u32 NYZ2      = 1 << YZ2BITS;
const u32 YZ2MASK   = NYZ2 - 1;
const u32 Z2BITS    = YZ2BITS - YBITS;
const u32 NZ2       = 1 << Z2BITS;
const u32 Z2MASK    = NZ2 - 1;
const u32 YZZBITS   = YZBITS + ZBITS;
const u32 YZZ1BITS  = YZ1BITS + ZBITS;

const u32 BIGSLOTBITS   = BIGSIZE * 8;
const u32 SMALLSLOTBITS = SMALLSIZE * 8;
const u64 BIGSLOTMASK   = (1ULL << BIGSLOTBITS) - 1ULL;
const u64 SMALLSLOTMASK = (1ULL << SMALLSLOTBITS) - 1ULL;
const u32 BIGSLOTBITS0  = BIGSIZE0 * 8;
const u64 BIGSLOTMASK0  = (1ULL << BIGSLOTBITS0) - 1ULL;
const u32 NONYZBITS     = BIGSLOTBITS0 - YZBITS;
const u32 NNONYZ        = 1 << NONYZBITS;

#ifndef BIGEPS
#define BIGEPS 33/64
#endif

// 176/256 is safely over 1-e(-1) ~ 0.63 trimming fraction
#ifndef TRIMFRAC256
#define TRIMFRAC256 310
#endif

const u32 NTRIMMEDZ  = NZ * TRIMFRAC256 / 256;

const u32 ZBUCKETSLOTS = NZ + NZ * BIGEPS;
#ifdef SAVEEDGES
const u32 ZBUCKETSIZE = NTRIMMEDZ * (BIGSIZE + sizeof(u32));  // assumes EDGEBITS <= 32
#else
const u32 ZBUCKETSIZE = ZBUCKETSLOTS * BIGSIZE0;
#endif
const u32 TBUCKETSIZE = ZBUCKETSLOTS * BIGSIZE;

template<u32 BUCKETSIZE>
struct bucket
{
  u32 size;
  // should avoid different values of RENAMESIZE in different threads of one process
  static const u32 RENAMESIZE = 2 * NZ2 + 2 * (COMPRESSROUND ? NZ1 : 0);
  union alignas(16)
  {
    u8 bytes[BUCKETSIZE];
    struct
    {
#ifdef SAVEEDGES
      u32 words[BUCKETSIZE / sizeof(u32) - RENAMESIZE - NTRIMMEDZ];
#else
      u32 words[BUCKETSIZE / sizeof(u32) - RENAMESIZE];
#endif
      u32 renameu1[NZ2];
      u32 renamev1[NZ2];
      u32 renameu[COMPRESSROUND ? NZ1 : 0];
      u32 renamev[COMPRESSROUND ? NZ1 : 0];
#ifdef SAVEEDGES
      u32 edges[NTRIMMEDZ];
#endif
    };
  };
  u32 setsize(u8 const* end)
  {
    size = end - bytes;
    assert(size <= BUCKETSIZE);
    return size;
  }
};

template<u32 BUCKETSIZE>
using bucket_row = bucket<BUCKETSIZE>[NY];
template <u32 BUCKETSIZE>
using matrix = bucket_row<BUCKETSIZE>[NX];

// 用于维护下一个写入位置的地址偏移
template<u32 BUCKETSIZE>
struct indexer
{
  offset_t offsets[NX];

  void makeoffset_v(const u32 y)
  {
    const bucket_row<BUCKETSIZE>* foo = 0;

    for (u32 x = 0; x < NX; x++)
      offsets[x] = foo[x][y].bytes - (u8*)foo;
  }
  offset_t store_v(bucket_row<BUCKETSIZE>* buckets, const u32 y)
  {
    u8 const* base = (u8*)buckets;
    offset_t sumsize = 0;

    for (u32 x = 0; x < NX; x++)
      sumsize += buckets[x][y].setsize(base + offsets[x]);

    return sumsize;
  }
  void makeoffset_u(const u32 x)
  {
    const bucket_row<BUCKETSIZE>* foo = 0;

    for (u32 y = 0; y < NY; y++)
      offsets[y] = foo[x][y].bytes - (u8*)foo;
  }
  offset_t store_u(bucket_row<BUCKETSIZE>* buckets, const u32 x)
  {
    u8 const* base = (u8*)buckets;
    offset_t sumsize = 0;

    for (u32 y = 0; y < NY; y++)
      sumsize += buckets[x][y].setsize(base + offsets[y]);

    return sumsize;
  }
};

#define likely(x)   __builtin_expect((x)!=0, 1)
#define unlikely(x) __builtin_expect((x), 0)

class trimmer_ctx; // 避免循环引用

// 用于传递线程所需参数
typedef struct
{
  u32 id;
  pthread_t thread;
  trimmer_ctx* et;
} thread_ctx;

typedef u8 deg_array[2 * MAXNZNYZ1];
typedef u16 zs_array[NTRIMMEDZ];
typedef u32 edges_array[NTRIMMEDZ];

// maintains set of trimmable edges
class trimmer_ctx
{
public:
  siphash_keys sip_keys;
  bucket_row<ZBUCKETSIZE>* bucketmatrix;
  bucket_row<TBUCKETSIZE>* tmpbuckets;
  edges_array* tmpedges;
  zs_array* tmpzs;
  deg_array* tmpdegs;
  offset_t* tmpcounts;
  u32 ntrims;
  u32 nthreads;
  bool showall;
  trim_barrier barry;

  void clear(u8* p, const offset_t n);
  trimmer_ctx(const u32 n_threads, const u32 n_trims, const bool show_all);
  ~trimmer_ctx();

  offset_t count() const;

  void genUnodes(const u32 id, const u32 uorv);

  void genVnodes(const u32 id, const u32 uorv);

  template <u32 SRCSIZE, u32 DSTSIZE, bool TRIMONV>
  void trimedges(const u32 id, const u32 round)
  {
    const u32 SRCSLOTBITS = std::min(SRCSIZE * 8, 2 * YZBITS);
    const u64 SRCSLOTMASK = (1ULL << SRCSLOTBITS) - 1ULL;
    const u32 SRCPREFBITS = SRCSLOTBITS - YZBITS;
    const u32 SRCPREFMASK = (1 << SRCPREFBITS) - 1;
    const u32 DSTSLOTBITS = std::min(DSTSIZE * 8, 2 * YZBITS);
    const u64 DSTSLOTMASK = (1ULL << DSTSLOTBITS) - 1ULL;
    const u32 DSTPREFBITS = DSTSLOTBITS - YZZBITS;
    const u32 DSTPREFMASK = (1 << DSTPREFBITS) - 1;
    indexer<ZBUCKETSIZE> dst;
    indexer<TBUCKETSIZE> small;
    offset_t sumsize = 0;
    u8 const* base = (u8*)bucketmatrix;
    u8 const* small0 = (u8*)tmpbuckets[id];
    const u32 startvx = NY *  id    / nthreads;
    const u32   endvx = NY * (id + 1) / nthreads;

    for (u32 vx = startvx; vx < endvx; vx++)
      {
        small.makeoffset_u(0);

        for (u32 ux = 0 ; ux < NX; ux++)
          {
            u32 uxyz = ux << YZBITS;
            bucket<ZBUCKETSIZE>& zb = TRIMONV ? bucketmatrix[ux][vx] : bucketmatrix[vx][ux];
            const u8* readbig = zb.bytes, *endreadbig = readbig + zb.size;

            for (; readbig < endreadbig; readbig += SRCSIZE)
              {
                const u64 e = *(u64*)readbig & SRCSLOTMASK;
                uxyz += ((u32)(e >> YZBITS) - uxyz) & SRCPREFMASK;
                const u32 vy = (e >> ZBITS) & YMASK;
                *(u64*)(small0 + small.offsets[vy]) = ((u64)uxyz << ZBITS) | (e & ZMASK);
                uxyz &= ~ZMASK;
                small.offsets[vy] += DSTSIZE;
              }
          }

        u8* degs = tmpdegs[id];
        small.store_u(tmpbuckets + id, 0);
        TRIMONV ? dst.makeoffset_v(vx) : dst.makeoffset_u(vx);

        for (u32 vy = 0 ; vy < NY; vy++)
          {
            const u64 vy34 = (u64)vy << YZZBITS;
            assert(NZ <= sizeof(deg_array));
            memset(degs, 0, NZ);
            u8*    readsmall = tmpbuckets[id][vy].bytes, *endreadsmall = readsmall + tmpbuckets[id][vy].size;

            for (u8* rdsmall = readsmall; rdsmall < endreadsmall; rdsmall += DSTSIZE)
              degs[*(u32*)rdsmall & ZMASK]++;

            u32 ux = 0;

            for (u8* rdsmall = readsmall; rdsmall < endreadsmall; rdsmall += DSTSIZE)
              {
                const u64 e = *(u64*)rdsmall & DSTSLOTMASK;
                ux += ((u32)(e >> YZZBITS) - ux) & DSTPREFMASK;
                *(u64*)(base + dst.offsets[ux]) = vy34 | ((e & ZMASK) << YZBITS) | ((e >> ZBITS) & YZMASK);
                dst.offsets[ux] += (degs[e & ZMASK] != 1) ? DSTSIZE : 0;
              }
          }

        sumsize += TRIMONV ? dst.store_v(bucketmatrix, vx) : dst.store_u(bucketmatrix, vx);
      }

    tmpcounts[id] = sumsize / DSTSIZE;
  }

  template <u32 SRCSIZE, u32 DSTSIZE, bool TRIMONV>
  void trimrename(const u32 id, const u32 round)
  {
    const u32 SRCSLOTBITS = std::min(SRCSIZE * 8, (TRIMONV ? YZBITS : YZ1BITS) + YZBITS);
    const u64 SRCSLOTMASK = (1ULL << SRCSLOTBITS) - 1ULL;
    const u32 SRCPREFBITS = SRCSLOTBITS - YZBITS;
    const u32 SRCPREFMASK = (1 << SRCPREFBITS) - 1;
    const u32 SRCPREFBITS2 = SRCSLOTBITS - YZZBITS;
    const u32 SRCPREFMASK2 = (1 << SRCPREFBITS2) - 1;
    indexer<ZBUCKETSIZE> dst;
    indexer<TBUCKETSIZE> small;
    u32 maxnnid = 0;
    offset_t sumsize = 0;
    u8 const* base = (u8*)bucketmatrix;
    u8 const* small0 = (u8*)tmpbuckets[id];
    const u32 startvx = NY *  id    / nthreads;
    const u32   endvx = NY * (id + 1) / nthreads;

    for (u32 vx = startvx; vx < endvx; vx++)
      {
        small.makeoffset_u(0);

        for (u32 ux = 0 ; ux < NX; ux++)
          {
            u32 uyz = 0;
            bucket<ZBUCKETSIZE>& zb = TRIMONV ? bucketmatrix[ux][vx] : bucketmatrix[vx][ux];
            const u8* readbig = zb.bytes, *endreadbig = readbig + zb.size;

            for (; readbig < endreadbig; readbig += SRCSIZE)
              {
                const u64 e = *(u64*)readbig & SRCSLOTMASK;

                if (TRIMONV)
                  uyz += ((u32)(e >> YZBITS) - uyz) & SRCPREFMASK;
                else uyz = e >> YZBITS;

                const u32 vy = (e >> ZBITS) & YMASK;
                *(u64*)(small0 + small.offsets[vy]) = ((u64)(ux << (TRIMONV ? YZBITS : YZ1BITS) | uyz) << ZBITS) | (e & ZMASK);

                if (TRIMONV)
                  uyz &= ~ZMASK;

                small.offsets[vy] += SRCSIZE;
              }
          }

        u16* degs = (u16*)tmpdegs[id];
        small.store_u(tmpbuckets + id, 0);
        TRIMONV ? dst.makeoffset_v(vx) : dst.makeoffset_u(vx);
        u32 newnodeid = 0;
        u32* renames = TRIMONV ? bucketmatrix[0][vx].renamev : bucketmatrix[vx][0].renameu;
        u32* endrenames = renames + NZ1;

        for (u32 vy = 0 ; vy < NY; vy++)
          {
            assert(2 * NZ <= sizeof(deg_array));
            memset(degs, 0, 2 * NZ);
            u8*    readsmall = tmpbuckets[id][vy].bytes, *endreadsmall = readsmall + tmpbuckets[id][vy].size;

            for (u8* rdsmall = readsmall; rdsmall < endreadsmall; rdsmall += SRCSIZE)
              degs[*(u32*)rdsmall & ZMASK]++;

            u32 ux = 0;
            u32 nrenames = 0;

            for (u8* rdsmall = readsmall; rdsmall < endreadsmall; rdsmall += SRCSIZE)
              {
                const u64 e = *(u64*)rdsmall & SRCSLOTMASK;

                if (TRIMONV)
                  ux += ((u32)(e >> YZZBITS) - ux) & SRCPREFMASK2;
                else ux = e >> YZZ1BITS;

                const u32 vz = e & ZMASK;
                u16 vdeg = degs[vz];

                if (vdeg != 1)
                  {
                    if (vdeg < 32)
                      {
                        degs[vz] = vdeg = 32 + nrenames++;
                        *renames++ = vy << ZBITS | vz;

                        if (renames == endrenames)
                          {
                            endrenames += (TRIMONV ? sizeof(bucket_row<ZBUCKETSIZE>) : sizeof(bucket<ZBUCKETSIZE>)) / sizeof(u32);
                            renames = endrenames - NZ1;
                          }
                      }

                    if (TRIMONV)
                      *(u64*)(base + dst.offsets[ux]) = ((u64)(newnodeid + vdeg - 32) << YZBITS) | ((e >> ZBITS) & YZMASK);
                    else *(u32*)(base + dst.offsets[ux]) = ((newnodeid + vdeg - 32) << YZ1BITS) | ((e >> ZBITS) & YZ1MASK);

                    dst.offsets[ux] += DSTSIZE;
                  }
              }

            newnodeid += nrenames;
          }

        if (newnodeid > maxnnid)
          maxnnid = newnodeid;

        sumsize += TRIMONV ? dst.store_v(bucketmatrix, vx) : dst.store_u(bucketmatrix, vx);
      }

    assert(maxnnid < NYZ1);
    tmpcounts[id] = sumsize / DSTSIZE;
  }

  template <bool TRIMONV>
  void trimedges1(const u32 id, const u32 round)
  {
    indexer<ZBUCKETSIZE> dst;
    offset_t sumsize = 0;
    u8* degs = tmpdegs[id];
    u8 const* base = (u8*)bucketmatrix;
    const u32 startvx = NY *  id    / nthreads;
    const u32   endvx = NY * (id + 1) / nthreads;

    for (u32 vx = startvx; vx < endvx; vx++)
      {
        TRIMONV ? dst.makeoffset_v(vx) : dst.makeoffset_u(vx);
        assert(NYZ1 <= sizeof(deg_array));
        memset(degs, 0xff, NYZ1);

        for (u32 ux = 0 ; ux < NX; ux++)
          {
            bucket<ZBUCKETSIZE>& zb = TRIMONV ? bucketmatrix[ux][vx] : bucketmatrix[vx][ux];
            u32* readbig = zb.words, *endreadbig = readbig + zb.size / sizeof(u32);

            for (; readbig < endreadbig; readbig++)
              degs[*readbig & YZ1MASK]++;
          }

        for (u32 ux = 0 ; ux < NX; ux++)
          {
            bucket<ZBUCKETSIZE>& zb = TRIMONV ? bucketmatrix[ux][vx] : bucketmatrix[vx][ux];
            u32* readbig = zb.words, *endreadbig = readbig + zb.size / sizeof(u32);

            for (; readbig < endreadbig; readbig++)
              {
                const u32 e = *readbig;
                const u32 vyz = e & YZ1MASK;
                *(u32*)(base + dst.offsets[ux]) = (vyz << YZ1BITS) | (e >> YZ1BITS);
                dst.offsets[ux] += degs[vyz] ? sizeof(u32) : 0;
              }
          }

        sumsize += TRIMONV ? dst.store_v(bucketmatrix, vx) : dst.store_u(bucketmatrix, vx);
      }

    tmpcounts[id] = sumsize / sizeof(u32);
  }

  template <bool TRIMONV>
  void trimrename1(const u32 id, const u32 round)
  {
    indexer<ZBUCKETSIZE> dst;
    u32 maxnnid = 0;
    offset_t sumsize = 0;
    u16* degs = (u16*)tmpdegs[id];
    u8 const* base = (u8*)bucketmatrix;
    const u32 startvx = NY *  id    / nthreads;
    const u32   endvx = NY * (id + 1) / nthreads;

    for (u32 vx = startvx; vx < endvx; vx++)
      {
        TRIMONV ? dst.makeoffset_v(vx) : dst.makeoffset_u(vx);
        memset(degs, 0xff, 2 * NYZ1); // sets each u16 entry to 0xffff

        for (u32 ux = 0 ; ux < NX; ux++)
          {
            bucket<ZBUCKETSIZE>& zb = TRIMONV ? bucketmatrix[ux][vx] : bucketmatrix[vx][ux];
            u32* readbig = zb.words, *endreadbig = readbig + zb.size / sizeof(u32);

            for (; readbig < endreadbig; readbig++)
              degs[*readbig & YZ1MASK]++;
          }

        u32 newnodeid = 0;
        u32* renames = TRIMONV ? bucketmatrix[0][vx].renamev1 : bucketmatrix[vx][0].renameu1;
        u32* endrenames = renames + NZ2;

        for (u32 ux = 0 ; ux < NX; ux++)
          {
            bucket<ZBUCKETSIZE>& zb = TRIMONV ? bucketmatrix[ux][vx] : bucketmatrix[vx][ux];
            u32* readbig = zb.words, *endreadbig = readbig + zb.size / sizeof(u32);

            for (; readbig < endreadbig; readbig++)
              {
                const u32 e = *readbig;
                const u32 vyz = e & YZ1MASK;
                u16 vdeg = degs[vyz];

                if (vdeg)
                  {
                    if (vdeg < 32)
                      {
                        degs[vyz] = vdeg = 32 + newnodeid++;
                        *renames++ = vyz;

                        if (renames == endrenames)
                          {
                            endrenames += (TRIMONV ? sizeof(bucket_row<ZBUCKETSIZE>) : sizeof(bucket<ZBUCKETSIZE>)) / sizeof(u32);
                            renames = endrenames - NZ2;
                            assert(renames < bucketmatrix[NX][0].renameu1);
                          }
                      }

                    *(u32*)(base + dst.offsets[ux]) = ((vdeg - 32) << (TRIMONV ? YZ1BITS : YZ2BITS)) | (e >> YZ1BITS);
                    dst.offsets[ux] += sizeof(u32);
                  }
              }
          }

        if (newnodeid > maxnnid)
          maxnnid = newnodeid;

        sumsize += TRIMONV ? dst.store_v(bucketmatrix, vx) : dst.store_u(bucketmatrix, vx);
      }

    assert(maxnnid < NYZ2);
    tmpcounts[id] = sumsize / sizeof(u32);
  }

  void trim();

  void barrier();

#ifdef EXPANDROUND
#define BIGGERSIZE BIGSIZE+1
#else
#define BIGGERSIZE BIGSIZE
#define EXPANDROUND COMPRESSROUND
#endif
  void trimmer(u32 id);
};

void* etworker(void* vp);

#define NODEBITS (EDGEBITS + 1)

// grow with cube root of size, hardly affected by trimming
// const u32 MAXPATHLEN = 16 << (EDGEBITS/3);

const u32 CUCKOO_SIZE = 2 * NX * NYZ1;

int nonce_cmp(const void* a, const void* b)
{
  return *(u32*)a - *(u32*)b;
}

typedef word_t proof[PROOFSIZE];

class Mean; // 避免循环引用

typedef struct
{
  u32 id;
  pthread_t thread;
  Mean* solver;
} match_ctx;

#define HEADERLEN 80

class Mean : public Pow
{
public:
  trimmer_ctx* trimctx;
  u32* cuckoo = 0;
  bool showcycle;
  proof cycleus;
  proof cyclevs;
  std::bitset<NXY> uxymap;
  std::vector<word_t> sols; // concatanation of all proof's indices

  Mean(char* header, int easipct = 50, const u32 n_threads = 4, const u32 n_trims = 68, bool allrounds = false,
       bool show_cycle = true);

  void setheadernonce(char* const headernonce, const u32 len, const u32 nonce);

  ~Mean();


  void graph() {}
  void cycle() {}
  void report() {}

  u64 sharedbytes() const;

  u32 threadbytes() const;

  void recordedge(const u32 i, const u32 u2, const u32 v2);

  void solution(const u32* us, u32 nu, const u32* vs, u32 nv);

  const u32 CUCKOO_NIL = ~0;

  u32 path(u32 u, u32* us) const;

  void findcycles();

  int run();

  void* matchUnodes(match_ctx* mc);
};

void* matchworker(void* vp);

};

#endif
