#pragma once
#include <pthread.h>
#include <errno.h>

#ifdef __APPLE__
typedef int pthread_barrierattr_t;
#endif

class trim_barrier
{
  pthread_mutex_t mutex;
  pthread_cond_t cond;
  unsigned limit;
  unsigned count;
  int phase;

public:
  trim_barrier(unsigned int count);

  ~trim_barrier();

  void clear();

  void abort();

  bool aborted();

  void wait();
};
