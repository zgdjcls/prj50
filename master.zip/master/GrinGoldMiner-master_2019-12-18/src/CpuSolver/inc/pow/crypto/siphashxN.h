#ifndef INCLUDE_SIPHASHXN_H
#define INCLUDE_SIPHASHXN_H

#include "siphash.h"

#define NSIPHASH 1

extern void siphash24xN(const siphash_keys* keys, const uint64_t* indices, uint64_t* hashes);

#endif // ifdef INCLUDE_SIPHASHXN_H
