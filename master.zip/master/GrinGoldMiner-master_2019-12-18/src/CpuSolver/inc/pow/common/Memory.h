#ifndef _MEMORY_H_
#define _MEMORY_H_

#include <cstdint>
#include <cstring>
#include <sstream>

#include "cuckoo/Log.h"

#define MEM_WIDTH 64
//#define STATICS

using namespace std;
namespace tensorchip
{

template <typename DataType, int BPW>
class Memory
{
public:
  Memory(uint32_t size, string name = "")
  {
    if (mem)
      free(mem);

    if (mem == nullptr)
      mem = (DataType*)malloc(size * sizeof(DataType));

    _maxSize = size;
    _name = name;
  }

  ~Memory()
  {
    if (mem)
      free(mem);
  }

  int set(DataType d, uint32_t addr, uint32_t len = 1)
  {
    if (len < 1)
      return -1;

    for (int i = 0; i < len; i++)
      mem[addr + i] = d;

    updateStatus(addr, len, false);
    return len;
  }

  int read(DataType* d, uint32_t addr, uint32_t len = 1)
  {
    uint64_t start, end, bits, words;
    memcpy(d, mem + addr, sizeof(DataType)*len);
    updateStatus(addr, len, true);
    return len;
  }

  int write(DataType* d, uint32_t addr, uint32_t len = 1)
  {
    uint64_t start, end, bits, words;
    memcpy(mem + addr, d, sizeof(DataType)*len);
    updateStatus(addr, len, false);
    return len;
  }

  uint32_t maxSize()
  {
    return _maxSize;
  }

  string report()
  {
    stringstream ss;
#ifdef STATICS
    ss << scientific;
    ss << "+------------------------------+" << endl;
    ss << "|    Memory Access Report      |" << endl;
    ss << "         (" << _name << ")" << endl;
    ss << "+------------------------------+" << endl;
    ss << "|        General Info          |" << endl;
    ss << "+------------------------------+" << endl;
    ss << "\ttotal memorySize : " << (double)_maxSize* BPW << endl;
    ss << "+------------------------------+" << endl;
    ss << "|         Read Access          |" << endl;
    ss << "+------------------------------+" << endl;
    ss << "\t#access : " << (double)nReadTimes << endl;
    ss << "\t#words  : " << (double)nReadWords << endl;
    ss << "\t#bits   : " << (double)nReadBits << endl;
    ss << "+------------------------------+" << endl;
    ss << "|         Write Access         |" << endl;
    ss << "+------------------------------+" << endl;
    ss << "\t#access : " << (double)nWriteTimes << endl;
    ss << "\t#words  : " << (double)nWriteWords << endl;
    ss << "\t#bits   : " << (double)nWriteBits << endl;
#endif
    return ss.str();
  }

private:

  void updateStatus(uint32_t addr, uint32_t len, bool read)
  {
#ifdef STATICS
    uint64_t start, end, bits, words;
    start = addr * BPW;
    bits = (uint64_t)len * BPW;
    end = start + bits - 1;
    words = end / MEM_WIDTH - start / MEM_WIDTH + 1;

    if (read)
      {
        nReadTimes++;
        nReadWords += words;
        nReadBits += bits;
      }
    else
      {
        nWriteTimes++;
        nWriteWords += words;
        nWriteBits += bits;
      }

#endif
  }

  uint32_t _maxSize;
  string _name;
  DataType* mem;
  uint64_t nReadTimes = 0;
  uint64_t nReadWords = 0;
  uint64_t nReadBits = 0;
  uint64_t nWriteTimes = 0;
  uint64_t nWriteWords = 0;
  uint64_t nWriteBits = 0;
};

}

#endif
