#include "Simple.h"
#include <cstring>

namespace tensorchip
{
Simple::Simple(char* header, int easipct) : Pow(header, easipct)
{
  //  easiness = easipct * (u64)NNODES / 100;
}

Simple::~Simple()
{
  if (cuckoo)
    free(cuckoo);
}


void Simple::reset(u32 nonce)
{
  Pow::reset(nonce);

  if (cuckoo == nullptr)
    cuckoo = new Memory<word_t, 32>(NCUCKOO, "cuckoo");
}

void Simple::graph()
{
}

void Simple::cycle()
{
  cuckoo->set(-1, 0, cuckoo->maxSize());
  Path pu, pv;

  for (int n = 0; n < easiness; n++)
    {
#if defined(VERBOSE) &&  VERBOSE > 0

      if (n % (int)1e06 == 0)
        LOG_D("Add %dth edges", n);

#endif
      Edge e = edge(n);
      pu = path(e.u);
      pv = path(e.v);

      if (pu.tail() == pv.tail())
        {
          // Cycle found
          Path cycle = genCycle(pu, pv);

          if (cycle.size() == PROOFSIZE)
            {
              addSolution(cycle);
              LOG_I("solution found\n");
            }

#if defined(DEBUG) && defined(VERIFY)
          int ret = verify(genSolution(cycle));

	  // *INDENT-OFF*
	  if (ret == POW_OK)
	    {
	      LOG_I("Solution verified");
	    }
	  else
	    {
	      LOG_F("Solution error with code=%d", ret);
	    }
	  // *INDENT-ON*
#endif
        }
      else
        {
          // Join path
          if (pu.size() < pv.size())
            {
              // revert path u
              for (int i = pu.size() - 1; i > 0; i--)
                {
                  word_t tmp = pu.value(i - 1);
                  cuckoo->write(&tmp, pu.value(i));
                }

              cuckoo->write(&e.v, pu.value(0));
            }
          else
            {
              // revert path v
              for (int i = pv.size() - 1; i > 0; i--)
                {
                  word_t tmp = pv.value(i - 1);
                  cuckoo->write(&tmp, pv.value(i));
                }

              cuckoo->write(&e.u, pv.value(0));
            }
        }
    }
}

void Simple::report()
{
  Pow::report();
  LOG_I("%s", cuckoo->report().c_str());
}

Path Simple::genCycle(Path pu, Path pv)
{
  Path cycle;
  int min = pu.size() < pv.size() ? pu.size() : pv.size();
  int u = pu.size() - min;
  int v = pv.size() - min;

  while (pu.value(u) != pv.value(v))
    {
      u++;
      v++;
    }

  for (int i = 0; i < u; i++)
    cycle.add(pu.value(i));

  for (int j = v; j >= 0; j--)
    cycle.add(pv.value(j));

  LOG_I("detect cycle size = %d", cycle.size());
  return cycle;
}

Path Simple::path(u32 node)
{
  Path p;
  word_t n = node;

  while (n < (1 << (sizeof(word_t) * 8 - 1)))
    {
      p.add(n);
      cuckoo->read(&n, n);
    }

  return p;
}


};

