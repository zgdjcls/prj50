#include "cuckoo/cuckoo.h"
#include "crypto/siphashxN.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <x86intrin.h>
#include <assert.h>
#include <vector>
#include <bitset>
#include "threads/barrier.h"
#include "Pow.h"
#include "Mean.h"

namespace tensorchip
{

void trimmer_ctx::clear(u8* p, const offset_t n)
{
  for (offset_t i = 0; i < n; i += 4096)
    * (u32*)(p + i) = 0;
}

trimmer_ctx::trimmer_ctx(const u32 n_threads, const u32 n_trims, const bool show_all) : barry(n_threads)
{
  assert(sizeof(matrix<ZBUCKETSIZE>) == NX * sizeof(bucket_row<ZBUCKETSIZE>));
  assert(sizeof(matrix<TBUCKETSIZE>) == NX * sizeof(bucket_row<TBUCKETSIZE>));
  nthreads = n_threads;
  ntrims   = n_trims;
  showall = show_all;
  bucketmatrix  = new bucket_row<ZBUCKETSIZE>[NX];
  clear((u8*)bucketmatrix, sizeof(matrix<ZBUCKETSIZE>));
  tmpbuckets = new bucket_row<TBUCKETSIZE>[nthreads];
  clear((u8*)tmpbuckets, nthreads * sizeof(bucket_row<TBUCKETSIZE>));
#ifdef SAVEEDGES
  tmpedges  = 0;
#else
  tmpedges  = new edges_array[nthreads];
#endif
  tmpdegs   = new deg_array[nthreads];
  tmpzs     = new zs_array[nthreads];
  tmpcounts = new offset_t[nthreads];
}

trimmer_ctx::~trimmer_ctx()
{
  delete[] bucketmatrix;
  delete[] tmpbuckets;
  delete[] tmpedges;
  delete[] tmpdegs;
  delete[] tmpzs;
  delete[] tmpcounts;
}

offset_t trimmer_ctx::count() const
{
  offset_t cnt = 0;

  for (u32 t = 0; t < nthreads; t++)
    cnt += tmpcounts[t];

  return cnt;
}

void trimmer_ctx::genUnodes(const u32 id, const u32 uorv)
{
  u64 rdtsc0, rdtsc1;
#ifdef NEEDSYNC
  u32 last[NX];;
#endif
  rdtsc0 = __rdtsc();
  u8 const* base = (u8*)bucketmatrix;
  indexer<ZBUCKETSIZE> dst;
  const u32 starty = NY *  id    / nthreads;
  const u32   endy = NY * (id + 1) / nthreads;
  u32 edge = starty << YZBITS, endedge = edge + NYZ;
  offset_t sumsize = 0;

  for (u32 my = starty; my < endy; my++, endedge += NYZ)
    {
      dst.makeoffset_v(my);
#ifdef NEEDSYNC

      for (u32 x = 0; x < NX; x++)
        last[x] = edge;

#endif

      for (; edge < endedge; edge += NSIPHASH)
        {
// bit        28..21     20..13    12..0
// node       XXXXXX     YYYYYY    ZZZZZ
          const u32 node = sipnode(&sip_keys, edge, uorv);
          const u32 ux = node >> YZBITS;
          const BIGTYPE0 zz = (BIGTYPE0)edge << YZBITS | (node & YZMASK);
#ifndef NEEDSYNC
// bit        39..21     20..13    12..0
// write        edge     YYYYYY    ZZZZZ
          *(BIGTYPE0*)(base + dst.offsets[ux]) = zz;
          dst.offsets[ux] += BIGSIZE0;
#else

          if (zz)
            {
              for (; unlikely(last[ux] + NNONYZ <= edge); last[ux] += NNONYZ, dst.offsets[ux] += BIGSIZE0)
                * (u32*)(base + dst.offsets[ux]) = 0;

              *(u32*)(base + dst.offsets[ux]) = zz;
              dst.offsets[ux] += BIGSIZE0;
              last[ux] = edge;
            }

#endif
        }

#ifdef NEEDSYNC

      for (u32 ux = 0; ux < NX; ux++)
        {
          for (; last[ux] < endedge - NNONYZ; last[ux] += NNONYZ)
            {
              *(u32*)(base + dst.offsets[ux]) = 0;
              dst.offsets[ux] += BIGSIZE0;
            }
        }

#endif
      sumsize += dst.store_v(bucketmatrix, my);
    }

  rdtsc1 = __rdtsc();

  if (!id) printf("genUnodes round %2d size %u rdtsc: %lu\n", uorv, sumsize / BIGSIZE0, rdtsc1 - rdtsc0);

  tmpcounts[id] = sumsize / BIGSIZE0;
}

void trimmer_ctx::genVnodes(const u32 id, const u32 uorv)
{
  u64 rdtsc0, rdtsc1;
  const u32 NONDEGBITS = std::min(BIGSLOTBITS, 2 * YZBITS) - ZBITS;
  const u32 NONDEGMASK = (1 << NONDEGBITS) - 1;
  indexer<ZBUCKETSIZE> dst;
  indexer<TBUCKETSIZE> small;
  rdtsc0 = __rdtsc();
  offset_t sumsize = 0;
  u8 const* base = (u8*)bucketmatrix;
  u8 const* small0 = (u8*)tmpbuckets[id];
  const u32 startux = NX *  id    / nthreads;
  const u32   endux = NX * (id + 1) / nthreads;

  for (u32 ux = startux; ux < endux; ux++)   // matrix x == ux
    {
      small.makeoffset_u(0);

      for (u32 my = 0 ; my < NY; my++)
        {
          u32 edge = my << YZBITS;
          u8*    readbig = bucketmatrix[ux][my].bytes;
          u8 const* endreadbig = readbig + bucketmatrix[ux][my].size;

// printf("id %d x %d y %d size %u read %d\n", id, ux, my, buckets[ux][my].size, readbig-base);
          for (; readbig < endreadbig; readbig += BIGSIZE0)
            {
// bit     39/31..21     20..13    12..0
// read         edge     UYYYYY    UZZZZ   within UX partition
              BIGTYPE0 e = *(BIGTYPE0*)readbig;
#if BIGSIZE0 > 4
              e &= BIGSLOTMASK0;
#elif defined NEEDSYNC

              if (unlikely(!e))
                {
                  edge += NNONYZ;
                  continue;
                }

#endif
              edge += ((u32)(e >> YZBITS) - edge) & (NNONYZ - 1);
// if (ux==78 && my==243) printf("id %d ux %d my %d e %08x prefedge %x edge %x\n", id, ux, my, e, e >> YZBITS, edge);
              const u32 uy = (e >> ZBITS) & YMASK;
// bit         39..13     12..0
// write         edge     UZZZZ   within UX UY partition
              *(u64*)(small0 + small.offsets[uy]) = ((u64)edge << ZBITS) | (e & ZMASK);
// printf("id %d ux %d y %d e %010lx e' %010x\n", id, ux, my, e, ((u64)edge << ZBITS) | (e >> YBITS));
              small.offsets[uy] += SMALLSIZE;
            }

          if (unlikely(edge >> NONYZBITS != (((my + 1) << YZBITS) - 1) >> NONYZBITS))
            {
              printf("OOPS1: id %d ux %d y %d edge %x vs %x\n", id, ux, my, edge, ((my + 1) << YZBITS) - 1);
              exit(0);
            }
        }

      u8* degs = tmpdegs[id];
      small.store_u(tmpbuckets + id, 0);
      dst.makeoffset_u(ux);

      for (u32 uy = 0 ; uy < NY; uy++)
        {
          assert(NZ <= sizeof(deg_array));
          memset(degs, 0xff, NZ);
          u8* readsmall = tmpbuckets[id][uy].bytes, *endreadsmall = readsmall + tmpbuckets[id][uy].size;

// if (id==1) printf("id %d ux %d y %d size %u sumsize %u\n", id, ux, uy, tbuckets[id][uy].size/BIGSIZE, sumsize);
          for (u8* rdsmall = readsmall; rdsmall < endreadsmall; rdsmall += SMALLSIZE)
            degs[*(u32*)rdsmall & ZMASK]++;

          u16* zs = tmpzs[id];
#ifdef SAVEEDGES
          u32* edges0 = bucketmatrix[ux][uy].edges;
#else
          u32* edges0 = tmpedges[id];
#endif
          u32* edges = edges0, edge = 0;

          for (u8* rdsmall = readsmall; rdsmall < endreadsmall; rdsmall += SMALLSIZE)
            {
// bit         39..13     12..0
// read          edge     UZZZZ    sorted by UY within UX partition
              const u64 e = *(u64*)rdsmall;
              edge += ((e >> ZBITS) - edge) & NONDEGMASK;
// if (id==0) printf("id %d ux %d uy %d e %010lx pref %4x edge %x mask %x\n", id, ux, uy, e, e>>ZBITS, edge, NONDEGMASK);
              *edges = edge;
              const u32 z = e & ZMASK;
              *zs = z;
              const u32 delta = degs[z] ? 1 : 0;
              edges += delta;
              zs    += delta;
            }

          if (unlikely(edge >> NONDEGBITS != EDGEMASK >> NONDEGBITS))
            {
              printf("OOPS2: id %d ux %d uy %d edge %x vs %x\n", id, ux, uy, edge, EDGEMASK);
              exit(0);
            }

          assert(edges - edges0 < NTRIMMEDZ);
          const u16* readz = tmpzs[id];
          const u32* readedge = edges0;
          int64_t uy34 = (int64_t)uy << YZZBITS;

          for (; readedge < edges; readedge++, readz++)   // process up to 7 leftover edges if NSIPHASH==8
            {
              const u32 node = sipnode(&sip_keys, *readedge, uorv);
              const u32 vx = node >> YZBITS; // & XMASK;
// bit        39..34    33..21     20..13     12..0
// write      UYYYYY    UZZZZZ     VYYYYY     VZZZZ   within VX partition
              *(u64*)(base + dst.offsets[vx]) = uy34 | ((u64) * readz << YZBITS) | (node & YZMASK);
// printf("id %d ux %d y %d edge %08x e' %010lx vx %d\n", id, ux, uy, *readedge, uy34 | ((u64)(node & YZMASK) << ZBITS) | *readz, vx);
              dst.offsets[vx] += BIGSIZE;
            }
        }

      sumsize += dst.store_u(bucketmatrix, ux);
    }

  rdtsc1 = __rdtsc();

  if (!id) printf("genVnodes round %2d size %u rdtsc: %lu\n", uorv, sumsize / BIGSIZE, rdtsc1 - rdtsc0);

  tmpcounts[id] = sumsize / BIGSIZE;
}

void trimmer_ctx::trim()
{
  void* etworker(void* vp);
  barry.clear();
  thread_ctx* threads = new thread_ctx[nthreads];

  for (u32 t = 0; t < nthreads; t++)
    {
      threads[t].id = t;
      threads[t].et = this;
      int err = pthread_create(&threads[t].thread, NULL, etworker, (void*)&threads[t]);
      assert(err == 0);
    }

  for (u32 t = 0; t < nthreads; t++)
    {
      int err = pthread_join(threads[t].thread, NULL);
      assert(err == 0);
    }

  delete[] threads;
}

void trimmer_ctx::barrier()
{
  barry.wait();
}

void trimmer_ctx::trimmer(u32 id)
{
  genUnodes(id, 0);
  barrier();
  genVnodes(id, 1);

  for (u32 round = 2; round < ntrims - 2; round += 2)
    {
      barrier();

      if (round < COMPRESSROUND)
        {
          if (round < EXPANDROUND)
            trimedges<BIGSIZE, BIGSIZE, true>(id, round);
          else if (round == EXPANDROUND)
            trimedges<BIGSIZE, BIGGERSIZE, true>(id, round);
          else trimedges<BIGGERSIZE, BIGGERSIZE, true>(id, round);
        }
      else if (round == COMPRESSROUND)
        trimrename<BIGGERSIZE, BIGGERSIZE, true>(id, round);
      else trimedges1<true>(id, round);

      barrier();

      if (round < COMPRESSROUND)
        {
          if (round + 1 < EXPANDROUND)
            trimedges<BIGSIZE, BIGSIZE, false>(id, round + 1);
          else if (round + 1 == EXPANDROUND)
            trimedges<BIGSIZE, BIGGERSIZE, false>(id, round + 1);
          else trimedges<BIGGERSIZE, BIGGERSIZE, false>(id, round + 1);
        }
      else if (round == COMPRESSROUND)
        trimrename<BIGGERSIZE, sizeof(u32), false>(id, round + 1);
      else trimedges1<false>(id, round + 1);
    }

  barrier();
  //trimrename1<true >(id, ntrims - 2);
  barrier();
  //trimrename1<false>(id, ntrims - 1);
}

void* etworker(void* vp)
{
  thread_ctx* tp = (thread_ctx*)vp;
  tp->et->trimmer(tp->id);
  pthread_exit(NULL);
  return 0;
}

Mean::Mean(char* header, int easipct, const u32 n_threads, const u32 n_trims, bool allrounds,
           bool show_cycle) : Pow(header, easipct)
{
  trimctx = new trimmer_ctx(n_threads, n_trims, allrounds);
  showcycle = show_cycle;
  cuckoo = 0;
  setheader(header, HEADERLEN, 10);//&trimctx->sip_keys    third one in setheader
  sols.clear();
}

Mean::~Mean()
{
  delete trimctx;
}

void Mean::setheadernonce(char* const headernonce, const u32 len, const u32 nonce)
{
  ((u32*)headernonce)[len / sizeof(u32) - 1] = htole32(nonce); // place nonce at end
  setheader(headernonce, len, &trimctx->sip_keys);
  sols.clear();
}

u64 Mean::sharedbytes() const
{
  return sizeof(matrix<ZBUCKETSIZE>);
}
u32 Mean::threadbytes() const
{
  return sizeof(thread_ctx) + sizeof(bucket_row<TBUCKETSIZE>) + sizeof(deg_array) + sizeof(zs_array) + sizeof(
           edges_array);
}

void Mean::recordedge(const u32 i, const u32 u2, const u32 v2)
{
  const u32 u1 = u2 / 2;
  const u32 ux = u1 >> YZ1BITS;
  // u32 uyz = trimctx->bucketmatrix[ux][(u1 >> Z2BITS) & YMASK].renameu1[u1 & Z2MASK];
  // assert(uyz < NYZ1);
  const u32 v1 = v2 / 2;
  const u32 vx = v1 >> YZ1BITS;
  // u32 vyz = trimctx->bucketmatrix[(v1 >> Z2BITS) & YMASK][vx].renamev1[v1 & Z2MASK];
  // assert(vyz < NYZ1);
#if COMPRESSROUND > 0
  uyz = trimctx->bucketmatrix[ux][(u1 >> Z1BITS) & YMASK].renameu[u1 & Z1MASK];
  vyz = trimctx->bucketmatrix[(v1 >> Z1BITS) & YMASK][vx].renamev[v1 & Z1MASK];
#endif
  const u32 u = cycleus[i] = (ux << YZBITS) | uyz;
  const u32 v = cyclevs[i] = (vx << YZBITS) | vyz;
  printf(" (%x,%x)", 2 * u, 2 * v + 1);
#ifdef SAVEEDGES
  u32* readedges = trimctx->bucketmatrix[ux][uyz >> ZBITS].edges, *endreadedges = readedges + NTRIMMEDZ;

  for (; readedges < endreadedges; readedges++)
    {
      u32 edge = *readedges;

      if (sipnode(&trimctx->sip_keys, edge, 1) == v && sipnode(&trimctx->sip_keys, edge, 0) == u)
        {
          sols.push_back(edge);
          return;
        }
    }

  assert(0);
#else
  uxymap[u >> ZBITS] = 1;
#endif
}

void Mean::solution(const u32* us, u32 nu, const u32* vs, u32 nv)
{
  printf("Nodes");
  u32 ni = 0;
  recordedge(ni++, *us, *vs);

  while (nu--)
    recordedge(ni++, us[(nu + 1) & ~1], us[nu | 1]); // u's in even position; v's in odd

  while (nv--)
    recordedge(ni++, vs[nv | 1], vs[(nv + 1) & ~1]); // u's in odd position; v's in even

  printf("\n");

  if (showcycle)
    {
#ifndef SAVEEDGES
      void* matchworker(void* vp);
      sols.resize(sols.size() + PROOFSIZE);
      match_ctx* threads = new match_ctx[trimctx->nthreads];

      for (u32 t = 0; t < trimctx->nthreads; t++)
        {
          threads[t].id = t;
          threads[t].solver = this;
          int err = pthread_create(&threads[t].thread, NULL, matchworker, (void*)&threads[t]);
          assert(err == 0);
        }

      for (u32 t = 0; t < trimctx->nthreads; t++)
        {
          int err = pthread_join(threads[t].thread, NULL);
          assert(err == 0);
        }

      delete[] threads;
#endif
      qsort(&sols[sols.size() - PROOFSIZE], PROOFSIZE, sizeof(u32), nonce_cmp);
    }
}

u32 Mean::path(u32 u, u32* us) const
{
  u32 nu, u0 = u;
  if(cuckoo[u] == 0){
    cuckoo[u] = CUCKOO_NIL;
  }

  for (nu = 0; u != CUCKOO_NIL; u = cuckoo[u])
    {
      if(cuckoo[u] == 0){
            cuckoo[u] = CUCKOO_NIL;
          }
      if (nu >= MAXPATHLEN)
        {
          while (nu-- && us[nu] != u) ;

          if (!~nu)
            printf("maximum path length exceeded\n");
          else printf("illegal %4d-cycle from node %d\n", MAXPATHLEN - nu, u0);

          pthread_exit(NULL);
        }

      us[nu++] = u;
    }

  return nu - 1;
}

void Mean::findcycles()
{
  u32 us[MAXPATHLEN], vs[MAXPATHLEN];
  u64 rdtsc0, rdtsc1;
  rdtsc0 = __rdtsc();

  for (u32 vx = 0; vx < NX; vx++)
    {
      for (u32 ux = 0 ; ux < NX; ux++)
        {
          bucket<ZBUCKETSIZE>& zb = trimctx->bucketmatrix[ux][vx];
          u32* readbig = zb.words, *endreadbig = readbig + zb.size / sizeof(u32);

// printf("vx %d ux %d size %u\n", vx, ux, zb.size/4);
          for (; readbig < endreadbig; readbig++)
            {
// bit        21..11     10...0
// write      UYYZZZ'    VYYZZ'   within VX partition
              const u32 e = *readbig;
              const u32 uxyz = (ux << YZ1BITS) | (e >> YZ1BITS);
              const u32 vxyz = (vx << YZ1BITS) | (e & YZ1MASK);
              const u32 u0 = uxyz << 1, v0 = (vxyz << 1) | 1;

              if (u0 != CUCKOO_NIL)
                {
                  u32 nu = path(u0, us), nv = path(v0, vs);

// printf("vx %02x ux %02x e %08x uxyz %06x vxyz %06x u0 %x v0 %x nu %d nv %d\n", vx, ux, e, uxyz, vxyz, u0, v0, nu, nv);
                  if (us[nu] == vs[nv])
                    {
                      const u32 min = nu < nv ? nu : nv;

                      for (nu -= min, nv -= min; us[nu] != vs[nv]; nu++, nv++) ;

                      const u32 len = nu + nv + 1;
                      printf("%4d-cycle found\n", len);
                      solution(us, nu, vs, nv);

                      if (len == PROOFSIZE)
                        solution(us, nu, vs, nv);
                    }
                  else if (nu < nv)
                    {
                      while (nu--)
                        cuckoo[us[nu + 1]] = us[nu];

                      cuckoo[u0] = v0;
                    }
                  else
                    {
                      while (nv--)
                        cuckoo[vs[nv + 1]] = vs[nv];

                      cuckoo[v0] = u0;
                    }
                }
            }
        }
    }

  rdtsc1 = __rdtsc();
  printf("findcycles rdtsc: %lu\n", rdtsc1 - rdtsc0);
}

int Mean::run()
{
  assert((u64)CUCKOO_SIZE * sizeof(u32) <= trimctx->nthreads * sizeof(bucket_row<TBUCKETSIZE>));
  trimctx->trim();
  cuckoo = (u32*)trimctx->tmpbuckets;
  memset(cuckoo, CUCKOO_NIL, CUCKOO_SIZE * sizeof(u32));
  findcycles();
  return sols.size() / PROOFSIZE;
}

void* Mean::matchUnodes(match_ctx* mc)
{
  u64 rdtsc0, rdtsc1;
  rdtsc0 = __rdtsc();
  const u32 starty = NY *  mc->id    / trimctx->nthreads;
  const u32   endy = NY * (mc->id + 1) / trimctx->nthreads;
  u32 edge = starty << YZBITS, endedge = edge + NYZ;

  for (u32 my = starty; my < endy; my++, endedge += NYZ)
    {
      for (; edge < endedge; edge += NSIPHASH)
        {
          // bit        28..21     20..13    12..0
          // node       XXXXXX     YYYYYY    ZZZZZ
          const u32 nodeu = sipnode(&trimctx->sip_keys, edge, 0);

          if (uxymap[nodeu >> ZBITS])
            {
              for (u32 j = 0; j < PROOFSIZE; j++)
                {
                  if (cycleus[j] == nodeu && cyclevs[j] == sipnode(&trimctx->sip_keys, edge, 1))
                    sols[sols.size() - PROOFSIZE + j] = edge;
                }
            }

          // bit        39..21     20..13    12..0
          // write        edge     YYYYYY    ZZZZZ
        }
    }

  rdtsc1 = __rdtsc();

  if (trimctx->showall || !mc->id) printf("matchUnodes id %d rdtsc: %lu\n", mc->id, rdtsc1 - rdtsc0);

  pthread_exit(NULL);
  return 0;
}

void* matchworker(void* vp)
{
  match_ctx* tp = (match_ctx*)vp;
  tp->solver->matchUnodes(tp);
  pthread_exit(NULL);
  return 0;
}

};
