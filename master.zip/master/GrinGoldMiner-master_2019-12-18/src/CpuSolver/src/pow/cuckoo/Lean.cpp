#include "Lean.h"

namespace tensorchip
{
twice_set::twice_set()
{
  bits = new Memory<atwice, BPW>(TWICE_ATOMS, "twice_set");
  bits->set(0, 0, bits->maxSize());
  assert(bits != nullptr);
}

void twice_set::clear()
{
  assert(bits != nullptr);
  bits->set(0, 0, bits->maxSize());
}

void twice_set::set(word_t u)
{
  word_t idx = u / TWICE_PER_ATOM;
  uatwice bit = (uatwice)1 << (2 * (u % TWICE_PER_ATOM));
  uatwice old;
  bits->read(&old, idx);
  old = old | (bit + (old & bit));
  bits->write(&old, idx);
}

bool twice_set::test(word_t u) const
{
  uatwice bit;
  bits->read(&bit, u / TWICE_PER_ATOM);
  return (bit >> (2 * (u % TWICE_PER_ATOM)) & 2) != 0;
}

twice_set::~twice_set()
{
  if (bits)
    free(bits);
}

shrinkingset::shrinkingset(const u32 nt)
{
  bits = new Memory<u64, 64>(NEDGES / 64, "shrinkingset");
  bits->set(0, 0, bits->maxSize());
  cnt  = (u64*)malloc(nt * sizeof(u64));
  nthreads = nt;
}

shrinkingset::~shrinkingset()
{
  if (bits)
    free(bits);

  free(cnt);
}

void shrinkingset::clear()
{
  bits->set(0, 0, bits->maxSize());
  memset(cnt, 0, nthreads * sizeof(u64));
  cnt[0] = NEDGES;
}

u64 shrinkingset::count() const
{
  u64 sum = 0LL;

  for (u32 i = 0; i < nthreads; i++)
    sum += cnt[i];

  return sum;
}

void shrinkingset::reset(word_t n, u32 thread)
{
  u64 bit;
  bits->read(&bit, n / 64);
  bit |= 1LL << (n % 64);
  bits->write(&bit, n / 64);
  cnt[thread]--;
}

bool shrinkingset::test(word_t n) const
{
  u64 bit;
  bits->read(&bit, n / 64);
  return !((bit >> (n % 64)) & 1LL);
}

u64 shrinkingset::block(word_t n) const
{
  u64 bit;
  bits->read(&bit, n / 64);
  return ~bit;
}

cuckoo_hash::cuckoo_hash(void* recycle)
{
  cuckoo = (Memory<au64, 64>*)recycle;

  for (u32 i = 0; i < CUCKOO_SIZE; i++)
    {
      au64 w = 0;
      cuckoo->write(&w, i);
    }
}

void cuckoo_hash::set(word_t u, word_t v)
{
  u64 niew = (u64)u << NODEBITS | v;

  for (word_t ui = u >> IDXSHIFT; ; ui = (ui + 1) & CUCKOO_MASK)
    {
      u64 old;
      cuckoo->read(&old, ui);

      if (old == 0 || (old >> NODEBITS) == (u & KEYMASK))
        {
          cuckoo->write(&niew, ui);
          return;
        }
    }
}

word_t cuckoo_hash::operator[](word_t u) const
{
  for (word_t ui = u >> IDXSHIFT; ; ui = (ui + 1) & CUCKOO_MASK)
    {
      u64 cu;
      cuckoo->read(&cu, ui);

      if (!cu)
        return 0;

      if ((cu >> NODEBITS) == (u & KEYMASK))
        {
          assert(((ui - (u >> IDXSHIFT)) & CUCKOO_MASK) < MAXDRIFT);
          return (word_t)(cu & NODEMASK);
        }
    }
}

cuckoo_ctx::cuckoo_ctx(u32 n_threads, u32 max_sols) : barry(n_threads)
{
  nthreads = n_threads;
  alive = new shrinkingset(nthreads);
  cuckoo = 0;
  nonleaf = new twice_set;
  sols = (word_t (*)[PROOFSIZE])calloc(maxsols = max_sols, PROOFSIZE * sizeof(word_t));
  assert(sols != 0);
  nsols = 0;
}

void cuckoo_ctx::setheadernonce(char* headernonce, const u32 len, const u32 nce)
{
  nonce = nce;
  ((u32*)headernonce)[len / sizeof(u32) - 1] = htole32(nonce); // place nonce at end
  setheader(headernonce, len, &sip_keys);
  alive->clear(); // set all edges to be alive
  nsols = 0;
}

cuckoo_ctx::~cuckoo_ctx()
{
  delete alive;
  delete nonleaf;
  delete cuckoo;
}

void cuckoo_ctx::barrier()
{
  barry.wait();
}

void cuckoo_ctx::abort()
{
  barry.abort();
}

void cuckoo_ctx::node_deg(const u64* hashes, const u32 nsiphash, const u32 part) const
{
  for (u32 i = 0; i < nsiphash; i++)
    {
#ifdef SKIPZERO

      if (!hashes[i])
        continue;

#endif
      u32 u = hashes[i] & EDGEMASK;

      if ((u & PART_MASK) == part)
        nonleaf->set(u >>= PART_BITS);
    }
}

void cuckoo_ctx::count_node_deg(const u32 id, const u32 uorv, const u32 part)
{
  alignas(64) u64 indices[NSIPHASH];
  alignas(64) u64 hashes[NPREFETCH];
  memset(hashes, 0, NPREFETCH * sizeof(u64)); // allow many nonleaf->set(0) to reduce branching
  u32 nidx = 0;

  for (word_t block = id * 64; block < NEDGES; block += nthreads * 64)
    {
      u64 alive64 = alive->block(block);

      for (word_t nonce = block - 1; alive64;)
        {
          // -1 compensates for 1-based ffs
          u32 ffs = __builtin_ffsll(alive64);
          nonce += ffs;
          alive64 >>= ffs;
          indices[nidx++ % NSIPHASH] = 2 * nonce + uorv;

          if (nidx % NSIPHASH == 0)
            {
              node_deg(hashes + nidx - NSIPHASH, NSIPHASH, part);
              siphash24xN(&sip_keys, indices, hashes + nidx - NSIPHASH);
              nidx %= NPREFETCH;
            }

          if (ffs & 64) break; // can't shift by 64
        }
    }

  node_deg(hashes, NPREFETCH, part);

  if (nidx % NSIPHASH != 0)
    {
      siphash24xN(&sip_keys, indices, hashes + (nidx & -NSIPHASH));
      node_deg(hashes + (nidx & -NSIPHASH), nidx % NSIPHASH, part);
    }
}

void cuckoo_ctx::kill(const u64* hashes, const u64* indices, const u32 nsiphash, const u32 part, const u32 id) const
{
  for (u32 i = 0; i < nsiphash; i++)
    {
#ifdef SKIPZERO

      if (!hashes[i])
        continue;

#endif
      u32 u = hashes[i] & EDGEMASK;

      if ((u & PART_MASK) == part && !nonleaf->test(u >> PART_BITS))
        alive->reset(indices[i] / 2, id);
    }
}

void cuckoo_ctx::kill_leaf_edges(const u32 id, const u32 uorv, const u32 part)
{
  alignas(64) u64 indices[NPREFETCH];
  alignas(64) u64 hashes[NPREFETCH];
  memset(hashes, 0, NPREFETCH * sizeof(u64)); // allow many nonleaf->test(0) to reduce branching
  u32 nidx = 0;

  for (word_t block = id * 64; block < NEDGES; block += nthreads * 64)
    {
      u64 alive64 = alive->block(block);

      for (word_t nonce = block - 1; alive64;)
        {
          // -1 compensates for 1-based ffs
          u32 ffs = __builtin_ffsll(alive64);
          nonce += ffs;
          alive64 >>= ffs;
          indices[nidx++] = 2 * nonce + uorv;

          if (nidx % NSIPHASH == 0)
            {
              siphash24xN(&sip_keys, indices + nidx - NSIPHASH, hashes + nidx - NSIPHASH);
              nidx %= NPREFETCH;
              kill(hashes + nidx, indices + nidx, NSIPHASH, part, id);
            }

          if (ffs & 64) break; // can't shift by 64
        }
    }

  const u32 pnsip = nidx & -NSIPHASH;

  if (pnsip != nidx)
    siphash24xN(&sip_keys, indices + pnsip, hashes + pnsip);

  kill(hashes, indices, nidx, part, id);
  const u32 nnsip = pnsip + NSIPHASH;
  kill(hashes + nnsip, indices + nnsip, NPREFETCH - nnsip, part, id);
}

void cuckoo_ctx::solution(word_t* us, u32 nu, word_t* vs, u32 nv)
{
  typedef std::pair<word_t, word_t> edge;
  std::set<edge> cycle;
  u32 n = 0;
  cycle.insert(edge(*us, *vs));

  while (nu--)
    cycle.insert(edge(us[(nu + 1) & ~1], us[nu | 1])); // u's in even position; v's in odd

  while (nv--)
    cycle.insert(edge(vs[nv | 1], vs[(nv + 1) & ~1])); // u's in odd position; v's in even

  u32 soli = nsols++;

  for (word_t block = 0; block < NEDGES; block += 64)
    {
      u64 alive64 = alive->block(block);

      for (word_t nonce = block - 1; alive64;)
        {
          // -1 compensates for 1-based ffs
          u32 ffs = __builtin_ffsll(alive64);
          nonce += ffs;
          alive64 >>= ffs;
          edge e(sipnode_(&sip_keys, nonce, 0), sipnode_(&sip_keys, nonce, 1));

          if (cycle.find(e) != cycle.end())
            {
              sols[soli][n++] = nonce;
#ifdef SHOWSOL
              printf("e(%x)=(%x,%x)%c", nonce, e.first, e.second, n == PROOFSIZE ? '\n' : ' ');
#endif

              if (PROOFSIZE > 2)
                cycle.erase(e);
            }

          if (ffs & 64) break; // can't shift by 64
        }
    }

  assert(n == PROOFSIZE);
}

u32 path(cuckoo_hash& cuckoo, word_t u, word_t* us)
{
  u32 nu;

  for (nu = 0; u; u = cuckoo[u])
    {
      if (nu >= LMAXPATHLEN)
        {
          while (nu-- && us[nu] != u) ;

          if (!~nu)
            printf("maximum path length exceeded\n");
          else printf("illegal %4d-cycle\n", LMAXPATHLEN - nu);

          pthread_exit(NULL);
        }

      us[nu++] = u;
    }

  return nu - 1;
}

void* worker(void* vp)
{
  thread_ctx* tp = (thread_ctx*)vp;
  cuckoo_ctx* ctx = tp->ctx;
  shrinkingset* alive = ctx->alive;
  u32 remain = NEDGES;
  u32 round = 0;

  // if (tp->id == 0) printf("initial size %d\n", NEDGES);
  while (remain > MAX_REMAINS)
    {
      // if (tp->id == 0) printf("round %2d partition sizes", round);
      for (u32 part = 0; part <= PART_MASK; part++)
        {
          if (tp->id == 0)
            ctx->nonleaf->clear(); // clear all counts

          ctx->barrier();
          ctx->count_node_deg(tp->id, round & 1, part);
          ctx->barrier();
          ctx->kill_leaf_edges(tp->id, round & 1, part);
          ctx->barrier();
          // if (tp->id == 0) printf(" %c%d %d", "UV"[round&1], part, alive->count());
        }

      round++;
      remain = alive->count();
      // if (tp->id == 0) printf("\n");
    }

  if (tp->id == 0)
    {
      u32 load = (u32)(100LL * alive->count() / CUCKOO_SIZE);
      printf("nonce %d: %d trims completed  final load %d%%\n", ctx->nonce, round, load);

      if (load >= 90)
        {
          printf("overloaded! exiting...");
          pthread_exit(NULL);
        }

      ctx->cuckoo = new cuckoo_hash(ctx->nonleaf->bits);
    }

#ifdef SINGLECYCLING
  else pthread_exit(NULL);

#else
  ctx->barrier();
#endif
  cuckoo_hash& cuckoo = *ctx->cuckoo;
  word_t us[LMAXPATHLEN], vs[LMAXPATHLEN];
#ifdef SINGLECYCLING

  for (word_t block = 0; block < NEDGES; block += 64)
    {
#else

  for (word_t block = tp->id * 64; block < NEDGES; block += ctx->nthreads * 64)
    {
#endif
      u64 alive64 = alive->block(block);

      for (word_t nonce = block - 1; alive64;)
        {
          // -1 compensates for 1-based ffs
          u32 ffs = __builtin_ffsll(alive64);
          nonce += ffs;
          alive64 >>= ffs;
          word_t u0 = sipnode_(&ctx->sip_keys, nonce, 0), v0 = sipnode_(&ctx->sip_keys, nonce, 1);

          if (u0)  // ignore vertex 0 so it can be used as nil for cuckoo[]
            {
              u32 nu = path(cuckoo, u0, us), nv = path(cuckoo, v0, vs);

              if (us[nu] == vs[nv])
                {
                  u32 min = nu < nv ? nu : nv;

                  for (nu -= min, nv -= min; us[nu] != vs[nv]; nu++, nv++) ;

                  u32 len = nu + nv + 1;
                  printf("%4d-cycle found at %d:%d%%\n", len, tp->id, (u32)(nonce * 100LL / NEDGES));

                  if (len == PROOFSIZE && ctx->nsols < ctx->maxsols)
                    ctx->solution(us, nu, vs, nv);
                }
              else if (nu < nv)
                {
                  while (nu--)
                    cuckoo.set(us[nu + 1], us[nu]);

                  cuckoo.set(u0, v0);
                }
              else
                {
                  while (nv--)
                    cuckoo.set(vs[nv + 1], vs[nv]);

                  cuckoo.set(v0, u0);
                }
            }

          if (ffs & 64) break; // can't shift by 64
        }
    }

  pthread_exit(NULL);
  return 0;
}

Lean::Lean(char* header, int easipct) : Pow(header, easipct)
{
  threads = (thread_ctx*)calloc(this->nthreads, sizeof(thread_ctx));
  assert(threads);
  ctx = new cuckoo_ctx(this->nthreads, MAXSOLS);
  ctx->sip_keys = this->sip_keys;
}

Lean::~Lean()
{
  free(threads);
  free(ctx);
}

void Lean::reset(u32 nonce)
{
  Pow::reset(nonce);
}

void Lean::graph()
{
}

void Lean::cycle()
{
  printf("find cycle by lean, PART_BITS = %d\n", PART_BITS);
  ctx->setheadernonce(this->header, sizeof(header), this->nonce);
  ctx->barry.clear();

  for (int t = 0; t < nthreads; t++)
    {
      threads[t].id = t;
      threads[t].ctx = ctx;
      int err = pthread_create(&threads[t].thread, NULL, worker, (void*)&threads[t]);
      assert(err == 0);
    }

  for (int t = 0; t < nthreads; t++)
    {
      int err = pthread_join(threads[t].thread, NULL);
      assert(err == 0);
    }
}

void Lean::report()
{
  LOG_I("%s", ctx->nonleaf->bits->report().c_str());
  LOG_I("%s", ctx->alive->bits->report().c_str());
  // LOG_I("%s", ctx->cuckoo->cuckoo->report().c_str());
}
};
