#include "Trim.h"
#include <cstring>
#include <assert.h>

namespace tensorchip
{
Trim::Trim(char* header, int easipct) : Pow(header, easipct)
{
}

Trim::~Trim()
{
  if (cuckoo)
    free(cuckoo);

  if (trim)
    free(trim);

  if (alive)
    free(alive);
}


void Trim::reset(u32 nonce)
{
  Pow::reset(nonce);

  if (cuckoo == nullptr)
    cuckoo = new Memory < remain_t, MAX_REMAINS_BITS + 1 > (MAX_REMAINS * 2, "cuckoo");

  if (cuckoo == nullptr)
    LOG_F("Failed to allocate memory to cuckoo");

  if (trim == nullptr)
    trim = new Memory<uint8_t, 2>(NCUCKOO / 2, "trim");

  if (trim == nullptr)
    LOG_F("Failed to allocate memory to trim");

  if (alive == nullptr)
    alive = new Memory<uint8_t, 8>((easiness + 7) / 8, "alive");

  if (alive == nullptr)
    LOG_F("Failed to allocate memory to alive");

  if (remains == nullptr)
    remains = new Memory<uint32_t, 32>(MAX_REMAINS, "remains");

  if (remains == nullptr)
    LOG_F("Failed to allocate memory to remains");

  if (index == nullptr)
    index = new Memory < remain_t, MAX_REMAINS_BITS + 1 > (MAX_REMAINS * 2, "index");

  if (index == nullptr)
    LOG_F("Failed to allocate memory to index");

  if (map == nullptr)
    map = new Memory < word_t, sizeof(word_t) * 8 > (MAX_REMAINS * 2, "map");

  if (map == nullptr)
    LOG_F("Failed to allocate memory to index");
}

void Trim::graph()
{
  int round = 0;
  int trimed = easiness, remain = easiness;
  alive->set(-1, 0, alive->maxSize());
  uint8_t alive_cache[ALIVE_CACHE_SIZE];
  uint16_t trim_cache[TRIM_CACHE_SIZE];

  while (remain > MAX_REMAINS)
    {
      round++;
      LOG_D("Started %dth round trim", round);
      // Init cuckoo (reused as counter in trim phase) to 0
      trim->set(0, 0, trim->maxSize());

      // count number of even end point
      for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
        {
          int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
          int size = (edges + 7) / 8;
          alive->read(alive_cache, n / 8, size);

          for (int i = 0; i < size; i++)
            {
              uint8_t live8 = alive_cache[i];
              trim_cache[i] = 0;

              for (int j = 0; j < 8; j++)
                {
                  int k = i * 8 + j;
                  assert(k < edges);
                  bool live = (live8 >> j) & 1;

                  if (live)
                    {
                      uint8_t old;
                      int e = round % 2 == 0 ? evenNode(n + k) : oddNode(n + k);
                      e = e / 2;
                      trim->read(&old, e);

                      if (!old)
                        trim_cache[i] |= (uint16_t)(1 << (2 * j + 1));
                      else
                        trim_cache[i] |= (uint16_t)(1 << (2 * j));
                    }
                }
            }

          for (int i = 0; i < size; i++)
            {
              uint8_t live8 = alive_cache[i];

              for (int j = 0; j < 8; j++)
                {
                  int k = i * 8 + j;

                  if (k >= edges)
                    break;

                  bool live = (live8 >> j) & 1;

                  if (live)
                    {
                      int e = round % 2 == 0 ? evenNode(n + k) : oddNode(n + k);
                      e = e / 2;
                      uint8_t count = 0;
                      bool testh = ((trim_cache[i] >> (2 * j)) & 1 != 0);
                      bool testl = ((trim_cache[i] >> (2 * j + 1)) & 1 != 0);

                      if (testh)
                        count = 2;
                      else
                        count = (testl == true) ? 1 : 0;

                      trim->write(&count, e);
                    }
                }
            }
        }

      // trim leaf
      trimed = 0;
      remain = 0;

      for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
        {
          int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
          int size = (edges + 7) / 8;
          alive->read(alive_cache, n / 8, size);

          for (int i = 0; i < size; i++)
            {
              uint8_t live8 = alive_cache[i];
              trim_cache[i] = 0;

              for (int j = 0; j < 8; j++)
                {
                  int k = i * 8 + j;
                  assert(k < edges);
                  bool live = (live8 >> j) & 1;

                  if (live)
                    {
                      uint8_t old;
                      int e = round % 2 == 0 ? evenNode(n + k) : oddNode(n + k);
                      e = e / 2;
                      trim->read(&old, e);

                      if (old == 2)
                        trim_cache[i] |= (uint16_t)(1 << (2 * j));
                    }
                }
            }

          for (int i = 0; i < size; i++)
            {
              uint8_t live8 = alive_cache[i];

              for (int j = 0; j < 8; j++)
                {
                  int k = i * 8 + j;

                  if (k >= edges)
                    break;

                  bool live = (live8 >> j) & 1;

                  if (live)
                    {
                      bool testh = ((trim_cache[i] >> (2 * j)) & 1 != 0);

                      if (!testh)
                        {
                          live8 &= ~(1 << j);
                          trimed++;
                        }
                      else
                        remain++;
                    }
                }

              alive_cache[i] = live8;
            }

          alive->write(alive_cache, n / 8, size);
        }

      LOG_D("trimed %d edges and %d edges remains alive", trimed, remain);
    }

  LOG_I("%d edges trimed and %d edges remains from total %d edges", easiness - remain, remain, easiness);
  LOG_I("Stores remain edge index to internal RAM");
  assert(remain < MAX_REMAINS && "Remain edges exceed RAM size");
  nRemains = 0;

  for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
    {
      int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
      int size = (edges + 7) / 8;
      alive->read(alive_cache, n / 8, size);

      for (int i = 0; i < size; i++)
        {
          uint8_t live8 = alive_cache[i];

          for (int j = 0; j < 8; j++)
            {
              int k = i * 8 + j;

              if (k >= edges)
                break;

              bool live = (live8 >> j) & 1;

              if (live)
                {
                  uint32_t e = n + k;
                  remains->write(&e, nRemains++);

                  if (nRemains == remain)
                    break;
                }
            }
        }
    }
}

void Trim::genIndex()
{
  for (int i = 0; i < nRemains; i++)
    {
      uint32_t n;
      bool find_u, find_v;
      remain_t uIndex, vIndex;
      remains->read(&n, i);
      Edge e = edge(n);
      map->write(&e.u, 2 * i);
      map->write(&e.v, 2 * i + 1);
      find_u = false;
      find_v = false;

      for (int j = 0; j < i; j++)
        {
          word_t u, v;
          map->read(&u, 2 * j);
          map->read(&v, 2 * j + 1);

          if (!find_u && e.u == u)
            {
              uIndex = 2 * j;
              index->write(&uIndex, 2 * i);
              find_u = true;
            }

          if (!find_v && e.v == v)
            {
              vIndex = 2 * j + 1;
              index->write(&vIndex, 2 * i + 1);
              find_v = true;
            }

          if (find_u && find_v)
            break;
        }

      if (!find_u)
        {
          uIndex = 2 * i;
          index->write(&uIndex, 2 * i);
        }

      if (!find_v)
        {
          vIndex = 2 * i + 1;
          index->write(&vIndex, 2 * i + 1);
        }
    }
}

void Trim::cycle()
{
  Path pu, pv;
  genIndex();
  cuckoo->set(-1, 0, cuckoo->maxSize());

  for (int i = 0; i < nRemains; i++)
    {
      uint32_t n;
      //remains->read(&n, i);
      //Edge e = edge(n);
      pu = path(2 * i);
      pv = path(2 * i + 1);

      if (pu.tail() == pv.tail())
        {
          // Cycle found
          Path cycle = genCycle(pu, pv);

          if (cycle.size() == PROOFSIZE)
            {
              addSolution(cycle);
              LOG_I("solution found\n");
            }

#if defined(DEBUG) && defined(VERIFY)
          int ret = verify(genSolution(cycle));

	  // *INDENT-OFF*
	  if (ret == POW_OK)
	    {
	      LOG_I("Solution verified");
	    }
	  else
	    {
	      LOG_F("Solution error with code=%d", ret);
	    }
	  // *INDENT-ON*
#endif
        }
      else
        {
          // Join path
          if (pu.size() < pv.size())
            {
              // revert path u
              for (int i = pu.size() - 1; i > 0; i--)
                {
                  remain_t tmp = pu.value(i - 1);
                  cuckoo->write(&tmp, pu.value(i));
                }

              //LOG_LOCATION;
              remain_t nIndex, nCuckoo;
              index->read(&nIndex, 2 * i + 1);
              cuckoo->read(&nCuckoo, nIndex);
              cuckoo->write(&nIndex, pu.value(0));
            }
          else
            {
              // revert path v
              for (int i = pv.size() - 1; i > 0; i--)
                {
                  remain_t tmp = pv.value(i - 1);
                  cuckoo->write(&tmp, pv.value(i));
                }

              //LOG_LOCATION;
              remain_t nIndex, nCuckoo;
              index->read(&nIndex, 2 * i);
              cuckoo->read(&nCuckoo, nIndex);
              cuckoo->write(&nIndex, pv.value(0));
            }
        }
    }
}

void Trim::report()
{
  Pow::report();
  LOG_I("%s", trim->report().c_str());
  LOG_I("%s", alive->report().c_str());
  LOG_I("%s", cuckoo->report().c_str());
  LOG_I("%s", remains->report().c_str());
  LOG_I("%s", index->report().c_str());
  LOG_I("%s", map->report().c_str());
}


Path Trim::path(remain_t node)
{
  Path p;
  remain_t n = node;
  remain_t nIndex, nCuckoo;
  index->read(&nIndex, n);

  while (nIndex < (1 << (sizeof(remain_t) * 8 - 1)))
    {
      p.add(nIndex);
      cuckoo->read(&nIndex, nIndex);
    }

  return p;
}

Path Trim::genCycle(Path pu, Path pv)
{
  Path cycle;
  int min = pu.size() < pv.size() ? pu.size() : pv.size();
  int u = pu.size() - min;
  int v = pv.size() - min;

  while (pu.value(u) != pv.value(v))
    {
      u++;
      v++;
    }

  for (int i = 0; i < u; i++)
    {
      word_t node;

      for (int j = 0; j < nRemains; j++)
        {
          remain_t nIndex;
          uint32_t k = i & 1 ? 2 * j + 1 : 2 * j;
          index->read(&nIndex, k);

          if (nIndex == pu.value(i))
            {
              map->read(&node, k);
              break;
            }
        }

      cycle.add(node);
    }

  for (int i = v; i >= 0; i--)
    {
      word_t node;

      for (int j = 0; j < nRemains; j++)
        {
          remain_t nIndex;
          uint32_t k = i & 1 ? 2 * j : 2 * j + 1;
          index->read(&nIndex, k);

          if (nIndex == pv.value(i))
            {
              map->read(&node, k);
              break;
            }
        }

      cycle.add(node);
    }

  LOG_I("detect cycle size = %d", cycle.size());
  return cycle;
}

};
