#include "Pow.h"
#include <cstring>
#include <chrono>

namespace tensorchip
{
Pow::Pow(char* header, int easipct)
{
  memcpy(this->header, header, HEADERLEN);
  this->easipct = easipct;
  easiness = easipct * (u64)NNODES / 100;
}

void Pow::set_keys(u64 k0, u64 k1, u64 k2, u64 k3)
{
  sip_keys.k0 = k0;
  sip_keys.k1 = k1;
  sip_keys.k2 = k2;
  sip_keys.k3 = k3;
  // clear solutions queue when new work arriving.
  solutions.clear();
}

void Pow::reset(u32 nonce)
{
  this->nonce = nonce;
  ((u32*)header)[HEADERLEN / sizeof(u32) - 1] = htole32(nonce);
  setheader(header, HEADERLEN, &sip_keys);
}

Edge Pow::edge(u32 n)
{
  return Edge(evenNode(n), oddNode(n));
}

void Pow::report()
{
  LOG_I("%ld solutions found\n", solutions.size());
#ifdef VERIFY

  for (vector<Path>::iterator it = solutions.begin(); it != solutions.end(); ++it)
    {
      int ret = verify(*it);

      // *INDENT-OFF*
      if (ret == POW_OK)
	{
	  LOG_I("Solution verified");
	}
      else
	{
	  LOG_F("Solution error with code=%d", ret);
	}
      // *INDENT-ON*
    }

#endif
}

int Pow::run()
{
  // Time epoch
  auto start = chrono::system_clock::now();
  // Generate graph
  graph();
  // Find cycle;
  cycle();
  // Calculate elipsed time
  auto end = chrono::system_clock::now();
  // Report
  report();
  std::chrono::duration<double> diff = end - start;
  LOG_I("Time elipsed %lfs", diff.count());
}

int Pow::numberOfEdges()
{
  return easiness;
}

u32 Pow::oddNode(u32 n)
{
  return 2 * sipnode(&sip_keys, n, 1) + 1;
}

u32 Pow::evenNode(u32 n)
{
  return 2 * sipnode(&sip_keys, n, 0);
}

Path Pow::genSolution(Path cycle)
{
  Path solution;

  for (int n = 0; n < easiness; n++)
    {
      Edge e = edge(n);

      if (cycle.find(e))
        solution.add(n);

      if (solution.size() == cycle.size())
        break;
    }

  return solution;
}


void Pow::addSolution(Path solution)
{
  solutions.push_back(solution);
}



int Pow::verify(Path solution)
{
  word_t size = solution.size();
  word_t* uvs = (word_t*)malloc(2 * size * sizeof(word_t));
  word_t xor0 = 0, xor1 = 0;

  for (u32 n = 0; n < size; n++)
    {
      if (solution.value(n) > EDGEMASK)
        return POW_TOO_BIG;

      if (n && solution.value(n) <= solution.value(n - 1))
        return POW_TOO_SMALL;

      Edge e = edge(solution.value(n));
      xor0 ^= uvs[2 * n  ] = e.u;
      xor1 ^= uvs[2 * n + 1] = e.v;
    }

  if (xor0 | xor1)            // optional check for obviously bad proofs
    return POW_NON_MATCHING;

  u32 n = 0, i = 0, j;

  do                          // follow cycle
    {
      for (u32 k = j = i; (k = (k + 2) % (2 * size)) != i;)
        {
          if (uvs[k] == uvs[i])   // find other edge endpoint identical to one at i
            {
              if (j != i)           // already found one before
                return POW_BRANCH;

              j = k;
            }
        }

      if (j == i) return POW_DEAD_END;  // no matching endpoint

      i = j ^ 1;
      n++;
    }
  while (i != 0);             // must cycle back to start or we would have found branch

  return n == size ? POW_OK : POW_SHORT_CYCLE;
}

u32 Pow::getSolution(u32* nonces)
{
  if (solutions.empty())
    return 0;

  for (int i = 0; i < PROOFSIZE; i++)
    nonces[i] = solutions.front().value(i);

  solutions.erase(solutions.begin());
  return PROOFSIZE;
}

};
