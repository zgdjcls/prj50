#include "crypto/siphashxN.h"

void siphash24xN(const siphash_keys* keys, const uint64_t* indices, uint64_t* hashes)
{
#if NSIPHASH == 1
  *hashes = keys->siphash24(*indices);
#else
#error not implemented
#endif
}
