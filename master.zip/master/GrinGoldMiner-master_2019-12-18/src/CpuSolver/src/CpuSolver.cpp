// Client side C/C++ program to demonstrate Socket programming
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "CpuSolver.h"

char stream[3000] = SOLUTION_INIT_PACKET;
SubmitSolution sol;
Pow* pow = NULL;

Job::Job()
{
  nonce = 0;
  height = 0;
  difficulty = 0;
  jobID = 0;
  scale = 0;
  hnonce = 0;
  k0 = 0;
  k1 = 0;
  k2 = 0;
  k3 = 0;
  valid = 0;
  memset(pre_pow, 0, sizeof(pre_pow));
}

Job::~Job()
{
}

void Job::getJob(char* buf)
{
  nonce = htole64(((uint64_t*)&buf[380])[0]);
  height = htole64(((uint64_t*)&buf[388])[0]);
  difficulty = htole64(((uint64_t*)&buf[396])[0]);
  jobID = htole64(((uint64_t*)&buf[404])[0]);
  scale = htole64(((uint64_t*)&buf[412])[0]);
  hnonce = htole64(((uint64_t*)&buf[420])[0]);
  k0 = htole64(((uint64_t*)&buf[428])[0]);
  k1 = htole64(((uint64_t*)&buf[436])[0]);
  k2 = htole64(((uint64_t*)&buf[444])[0]);
  k3 = htole64(((uint64_t*)&buf[452])[0]);
  strncpy(pre_pow, (char*)&buf[466], 477);
  origin = buf[1065];
}

void Job::printJob()
{
  LOG_I("\n-------- Print Job Info --------\n");
  LOG_I("    nonce: 0x%016lx\n", nonce);
  LOG_I("    height: 0x%016lx\n", height);
  LOG_I("    difficulty: 0x%016lx\n", difficulty);
  LOG_I("    jobID: 0x%016lx\n", jobID);
  LOG_I("    scale: 0x%016lx\n", scale);
  LOG_I("    hnonce: 0x%016lx\n", hnonce);
  LOG_I("    k0: 0x%016lx\n", k0);
  LOG_I("    k1: 0x%016lx\n", k1);
  LOG_I("    k2: 0x%016lx\n", k2);
  LOG_I("    k3: 0x%016lx\n", k3);
  LOG_I("    origin: %d\n", origin);
  LOG_I("    pre pow: %s\n", pre_pow);
  LOG_I("--------------------------------\n");
}

SubmitSolution::SubmitSolution()
{
  memset(nonces, 0, sizeof(nonces));
  share_difficulty = 0;
  fidelity = 0;
  job = NULL;
}

SubmitSolution::~SubmitSolution()
{
}

void SubmitSolution::genStream(char* buf)
{
  memcpy(buf + 378, &share_difficulty, 8);
  memcpy(buf + 658, job, 579);
  memcpy(buf + 1595, nonces, 168);
}

// Convert C++ time to C# DateTime
uint64_t getNowTime()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec * 10000000 + tv.tv_usec * 10 + 0x089f803905d8c000;
}

void* sendSolutions(void* sock)
{
  while (1)
    {
#ifdef SERIALIZATION_TEST

      if ((sol.job != NULL) && (sol.job->valid == 1))
#else
      if ((sol.job != NULL) && (sol.job->valid == 1) && (pow->getSolution(sol.nonces) == PROOFSIZE))
#endif
        {
          sol.job->solvedAt = getNowTime();
          sol.genStream(stream);
          send(*((int*)sock), stream, SOLUTION_PACKET_LEN, 0);
        }

      usleep(100000);
#ifdef SERIALIZATION_TEST
      sleep(10);
#endif
    }
}

int main(int argc, char const* argv[])
{
  int sock = 0;
  int deviceID = 0;
  int port = 13500;
  int gpuCount = 0;
  char serverIP[20] = {0};
  int read_len = 0;
  int total_len = 0;
  char buffer[2000] = {0};
  pthread_t tid;
  struct sockaddr_in serv_addr;
  Job currJob, nextJob;
  memset(&serv_addr, 0, sizeof(serv_addr));

  // Parse args
  if (argc >= 5)
    {
      deviceID = atoi(argv[1]);
      port = atoi(argv[2]);
      gpuCount = atoi(argv[4]);
      LOG_D("deviceID:%d, port:%d, gpuNum:%d.\n",  deviceID, port, gpuCount);
    }
  else
    {
      LOG_E("Args parse error, agrs too few.\n");
      return -1;
    }

  if ((argc == 6) && (strlen(argv[5]) < 16))
    strcpy(serverIP, argv[5]);
  else
    strcpy(serverIP, "127.0.0.1");

  // Init socket
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(port);

  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      LOG_E("\n Socket creation error.\n");
      return -1;
    }

  // Convert IPv4 and IPv6 addresses from text to binary form
  if (inet_pton(AF_INET, serverIP, &serv_addr.sin_addr) <= 0)
    {
      LOG_E("\nInvalid address/ Address not supported.\n");
      return -1;
    }

  // Connect to master
  if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0)
    {
      LOG_E("\nMaster Connection Failed.\n");
      return -1;
    }

  // pow init
  pow = (Pow*)
#ifdef TRIM
        (new Trim(new char[HEADERLEN]));
#else
        (new Simple(new char[HEADERLEN]));
#endif
  // Call reset func to init cuckoo pointer
  pow->reset(0);

  // Create thread to send solutions to master
  if (pthread_create(&tid, NULL, sendSolutions, &sock) != 0)
    LOG_E("Create pthread to send solutions failed.\n");

  sol.job = &currJob;

  while (1) // connect alive
    {
      // Read sock buffer
      read_len = 0;
      total_len = 0;
      memset(buffer, 0, sizeof(buffer));

      while (1)
        {
          read_len = read(sock, &buffer[total_len], sizeof(buffer));
          total_len += read_len;

          if (total_len == GPUSET_PACKET_LEN || total_len == JOB_PACKET_LEN)
            break;

          if (total_len > JOB_PACKET_LEN)
            {
              read_len = 0;
              total_len = 0;
              memset(buffer, 0, sizeof(buffer));
            }

          usleep(100000);
        }

      if (total_len == JOB_PACKET_LEN)
        {
          LOG_D("\nGet a new job.\n");
          nextJob.getJob(buffer);
        }
      else if (total_len == GPUSET_PACKET_LEN)
        {
          LOG_D("\nGet a GPU Settings.\n");
          // Sleep 1s
          sleep(1);
          continue;
        }
      else
        {
          LOG_D("Waiting for a job ...\n");
          // Sleep 1s
          sleep(1);
          continue;
        }

      if ((currJob.pre_pow != nextJob.pre_pow) || (currJob.origin != nextJob.origin))
        {
          currJob = nextJob;
          currJob.timestamp = getNowTime();
        }

      // Old job?
      if (currJob.timestamp + 18000000000 < getNowTime())
        {
          LOG_W("Job too old...\n");
          currJob.valid = 0;
          sleep(1);
          continue;
        }

#ifdef DEBUG
      currJob.printJob();
#endif
      // set k values, and clear solutions queue.
      pow->set_keys(currJob.k0, currJob.k1, currJob.k2, currJob.k3);
      currJob.valid = 1;
#ifndef SERIALIZATION_TEST
      pow->run();
#endif
    }

  pthread_exit(NULL);
  return 0;
}
