#ifdef TRIM
#include "Trim.h"
#elif LEAN
#include "Lean.h"
#elif MEAN
#include "Mean.h"
#else
#include "Simple.h"
#endif

using namespace std;
using namespace tensorchip;

int main()
{
  char header[HEADERLEN];
  memset(header, 0, HEADERLEN);
  LOG_I("ALGORITHM=%s", ALGORITHM);
  Pow* pow = (Pow*)
#ifdef TRIM
             (new Trim(header));
  LOG_I("SOLVER=TRIM");
#elif LEAN
             (new Lean(header));
  LOG_I("SOLVER=LEAN");
#elif MEAN
             (new Mean(header));
  LOG_I("SOLVER=MEAN");
#else
             (new Simple(header));
  LOG_I("SOLVER=SIMPLE");
#endif
  LOG_I("EDGEBITS=%d", EDGEBITS);
  LOG_I("Easiness=%e", (double)pow->numberOfEdges());
  pow->reset(0);
  pow->run();
  return 0;
}
