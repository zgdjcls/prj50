# reset工程重建步骤
# http://tensorth.tpddns.cn:8090/pages/viewpage.action?pageId=8258093

