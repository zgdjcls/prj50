#include "pow_accel.h"
extern "C" {
  void graph_accel(uint64_t* keys, uint32_t* remains, int* n_remains, mem_accel* alive, int easiness_accel,
                   mem_accel* trim0, mem_accel* trim1, mem_accel* trim2, mem_accel* trim3, mem_accel* trim4, mem_accel* trim5,
                   mem_accel* trim6, mem_accel* trim7)
  {
    siphash_keys_accel sip_keys;
    sip_keys.k0 = keys[0];
    sip_keys.k1 = keys[1];
    sip_keys.k2 = keys[2];
    sip_keys.k3 = keys[3];
    int easiness = EASINESS; //easiness_accel;EASINESS
    int round = 0;
    int trimed = easiness, remain = easiness;
    mem_accel alive_cache[ALIVE_CACHE_SIZE];
    uint32_t remains_buffer[REMAINS_CACHE_SIZE];
    uint32_t nRemains = 0;
// ****************** funcion body of graph ******************
// ******* alive DDR initialization **********
    memory_set_accel(alive, (mem_accel)(-1), 0, (easiness + WIDTH_ACCEL - 1) / WIDTH_ACCEL);
loop_while:

    while (remain > MAX_REMAINS)
      {
        round++;
        trimed = 0;
        remain = 0;
        //Init cuckoo (reused as counter in trim phase) to 0
        trim_init(trim0, trim1, trim2, trim3, trim4, trim5, trim6, trim7);
        // count number of even end point
loop_count:

        for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
          {
            int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
            int size = (edges + WIDTH_ACCEL - 1) / WIDTH_ACCEL;
            memory_read_accel(alive, alive_cache, n / WIDTH_ACCEL, size);
loop_alive_read_1:

            for (int i = 0; i < size; i++)
              {
                mem_accel live_word = alive_cache[i];
loop_alive_value_read_1:

                for (int j = 0; j < WIDTH_ACCEL; j++)
                  {
                    int k = i * WIDTH_ACCEL + j;

                    if (k >= edges)
                      break;

                    bool live = (live_word >> j) & 1;

                    if (live)
                      {
                        mem_accel count, count_tmp;
                        mem_accel trim_count;
                        int e =  round % 2 == 0 ? evenNode(n + k, sip_keys) : oddNode(n + k, sip_keys);
                        //count = trim[e];
                        int channel = e / (CHANNEL_NCUCKOO);
                        int offset = e % (CHANNEL_NCUCKOO);
                        int x = offset / (WIDTH_ACCEL / 8);
                        int y = 8 * (offset % (WIDTH_ACCEL / 8));

                        if (channel > 7)
                          std::cout << "error" << std::endl;

                        switch (channel)
                          {
                          case 0:
                            trim_count = trim0[x];
                            break;

                          case 1:
                            trim_count = trim1[x];
                            break;

                          case 2:
                            trim_count = trim2[x];
                            break;

                          case 3:
                            trim_count = trim3[x];
                            break;

                          case 4:
                            trim_count = trim4[x];
                            break;

                          case 5:
                            trim_count = trim5[x];
                            break;

                          case 6:
                            trim_count = trim6[x];
                            break;

                          case 7:
                            trim_count = trim7[x];
                            break;

                          default:
                            break;
                          }

                        //trim_count = trim[x];
                        count = (trim_count >> y) & 0b11111111;

                        if (count < 2)
                          count_tmp = count + 1;
                        else
                          count_tmp = count;

                        trim_count = trim_count - (count << y) + (count_tmp << y);

                        switch (channel)
                          {
                          case 0:
                            trim0[x] = trim_count;
                            break;

                          case 1:
                            trim1[x] = trim_count;
                            break;

                          case 2:
                            trim2[x] = trim_count;
                            break;

                          case 3:
                            trim3[x] = trim_count;
                            break;

                          case 4:
                            trim4[x] = trim_count;
                            break;

                          case 5:
                            trim5[x] = trim_count;
                            break;

                          case 6:
                            trim6[x] = trim_count;
                            break;

                          case 7:
                            trim7[x] = trim_count;
                            break;

                          default:
                            break;
                          }

                        //trim[x] = trim_count;
                      }
                  }
              }
          }

loop_trim:

        for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
          {
            int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
            int size = (edges + WIDTH_ACCEL - 1) / WIDTH_ACCEL;
            memory_read_accel(alive, alive_cache, n / WIDTH_ACCEL, size);
loop_alive_read_2:

            for (int i = 0; i < size; i++)
              {
                mem_accel live_word = alive_cache[i];
                mem_accel live_tmp = live_word;
loop_alive_value_read_2:

                for (int j = 0; j < WIDTH_ACCEL; j++)
                  {
                    int k = i * WIDTH_ACCEL + j;

                    if (k >= edges)
                      break;

                    bool live = (live_word >> j) & 1;

                    if (live)
                      {
                        mem_accel trim_count, count;
                        int e =  round % 2 == 0 ? evenNode(n + k, sip_keys) : oddNode(n + k, sip_keys);
                        int channel = e / (CHANNEL_NCUCKOO);
                        int offset = e % (CHANNEL_NCUCKOO);
                        int x = offset / (WIDTH_ACCEL / 8);
                        int y = 8 * (offset % (WIDTH_ACCEL / 8));

                        switch (channel)
                          {
                          case 0:
                            trim_count = trim0[x];
                            break;

                          case 1:
                            trim_count = trim1[x];
                            break;

                          case 2:
                            trim_count = trim2[x];
                            break;

                          case 3:
                            trim_count = trim3[x];
                            break;

                          case 4:
                            trim_count = trim4[x];
                            break;

                          case 5:
                            trim_count = trim5[x];
                            break;

                          case 6:
                            trim_count = trim6[x];
                            break;

                          case 7:
                            trim_count = trim7[x];
                            break;

                          default:
                            break;
                          }

                        //count = trim[e];
                        count = (trim_count >> y) & 0b11111111;

                        if (count < 2)
                          {
                            live_tmp &= ~((mem_accel)1 << j);
                            trimed++;
                          }
                        else
                          remain++;
                      }
                  }

                alive_cache[i] = live_tmp;
              }

            memory_write_accel(alive_cache, alive, n / WIDTH_ACCEL, size);
            //alive->write(alive_cache, n / WIDTH, size);
          }

        // std::cout << "trimed " << trimed << " edges and " << remain << " edges remains alive" << std::endl;
      }

    nRemains = 0;
    uint32_t block = 0;
loop_remains_write:

    for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
      {
        int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
        int size = (edges + WIDTH_ACCEL - 1) / WIDTH_ACCEL;
        // alive->read(alive_cache, n / WIDTH, size);
        memory_read_accel(alive, alive_cache, n / WIDTH_ACCEL, size);
loop_alive_read_3:

        for (int i = 0; i < size; i++)
          {
            mem_accel live_word = alive_cache[i];
loop_alive_value_read_3:

            for (int j = 0; j < WIDTH_ACCEL; j++)
              {
                int k = i * WIDTH_ACCEL + j;

                if (k >= edges)
                  break;

                bool live = (live_word >> j) & 1;

                if (live)
                  {
                    uint32_t e = n + k;

                    //remains->write(&e, nRemains++);
                    if (nRemains == REMAINS_CACHE_SIZE)
                      {
                        memory_write_accel(remains_buffer, remains, block * REMAINS_CACHE_SIZE, REMAINS_CACHE_SIZE);
                        nRemains = 0;
                        block = block + 1;
                      }

                    remains_buffer[nRemains++] = e;
                  }
              }
          }

        if ((int)(block * REMAINS_CACHE_SIZE + nRemains) >= (int)remain)
          break;
      }

    n_remains[0] = remain;
    memory_write_accel(remains_buffer, remains, block * REMAINS_CACHE_SIZE, nRemains);
  }
  void cycle_accel(uint32_t* remains, int* n_remains, uint64_t* keys, uint32_t* find,
                   uint32_t solutions[SOLUTIONS_SIZE][PROOFSIZE], uint16_t* solutions_len)
  {
    siphash_keys_accel sip_keys;
    sip_keys.k0 = keys[0];
    sip_keys.k1 = keys[1];
    sip_keys.k2 = keys[2];
    sip_keys.k3 = keys[3];
    *find = 0;
    uint32_t nRemains = n_remains[0];
    remain_t cuckoo_buffer[MAX_REMAINS * 2];
    uint32_t map_buffer[MAX_REMAINS * 2];
    remain_t index_buffer[MAX_REMAINS * 2];
    uint32_t solutions_buffer[SOLUTIONS_SIZE][PROOFSIZE];
    uint16_t solutions_len_buffer = 0;
    // ****************** funcion body of cycle ******************
    Path_Accel pu, pv;
    genIndex_accel(nRemains, remains, map_buffer, index_buffer, sip_keys);
    //cuckoo->set(-1, 0, cuckoo->maxSize());
    memory_set_accel(cuckoo_buffer, (remain_t) -1, 0, MAX_REMAINS * 2);

    for (int i = 0; i < nRemains; i++)
      {
        //uint32_t n;
        //remains->read(&n, i);
        //Edge e = edge(n);
        pu = path_accel(2 * i, index_buffer, cuckoo_buffer);
        pv = path_accel(2 * i + 1, index_buffer, cuckoo_buffer);

        if (pu.tail() == pv.tail())
          {
            // Cycle found
            Path_Accel cycle = genCycle_accel(pu, pv, nRemains, index_buffer, map_buffer);

            if (cycle.size() == PROOFSIZE)
              {
                // addSolution(cycle);
                // LOG_I("solution found\n");
                std::cout << "****************solution found***************" << std::endl;

                for (int i = 0; i < PROOFSIZE; i++)
                  solutions_buffer[solutions_len_buffer][i] = cycle.value(i);

                solutions_len_buffer++;
                *find = 1;
              }

#if defined(DEBUG) && defined(VERIFY)
            int ret = verify(genSolution(cycle));

  	  // *INDENT-OFF*
  	  if (ret == POW_OK)
  	    {
  	      LOG_I("Solution verified");
  	    }
  	  else
  	    {
  	      LOG_F("Solution error with code=%d", ret);
  	    }
  	  // *INDENT-ON*
#endif
          }
        else
          {
            // Join path
            if (pu.size() < pv.size())
              {
                // revert path u
                for (int i = pu.size() - 1; i > 0; i--)
                  {
                    remain_t tmp = pu.value(i - 1);
                    //cuckoo->write(&tmp, pu.value(i));
                    memory_write_accel(tmp, cuckoo_buffer, pu.value(i), 1);
                  }

                //LOG_LOCATION;
                remain_t nIndex, nCuckoo;
                //index->read(&nIndex, 2 * i + 1);
                //cuckoo->read(&nCuckoo, nIndex);
                //cuckoo->write(&nIndex, pu.value(0));
                nIndex = memory_read_accel(index_buffer, 2 * i + 1);
                nCuckoo = memory_read_accel(cuckoo_buffer, nIndex);
                memory_write_accel(nIndex, cuckoo_buffer, pu.value(0), 1);
              }
            else
              {
                // revert path v
                for (int i = pv.size() - 1; i > 0; i--)
                  {
                    remain_t tmp = pv.value(i - 1);
                    //cuckoo->write(&tmp, pv.value(i));
                    memory_write_accel(tmp, cuckoo_buffer, pv.value(i), 1);
                  }

                //LOG_LOCATION;
                remain_t nIndex, nCuckoo;
                //index->read(&nIndex, 2 * i);
                //cuckoo->read(&nCuckoo, nIndex);
                //cuckoo->write(&nIndex, pv.value(0));
                nIndex = memory_read_accel(index_buffer, 2 * i);
                nCuckoo = memory_read_accel(cuckoo_buffer, nIndex);
                memory_write_accel(nIndex, cuckoo_buffer, pv.value(0), 1);
              }
          }
      }

    // ************************* data output **************************************
    if (*find == 1)
      {
loop_write_solutions:

        for (int i = 0; i < solutions_len_buffer; i++)
          for (int j = 0; j < PROOFSIZE; j++)
            solutions[i][j] = solutions_buffer[i][j];

        *solutions_len = solutions_len_buffer;
      }
  }
  void pow_accel(uint64_t* keys, uint32_t* find, uint32_t solutions[SOLUTIONS_SIZE][PROOFSIZE], uint16_t* solutions_len,
                 mem_t* alive, int easiness,
                 mem_accel* trim0, mem_accel* trim1, mem_accel* trim2, mem_accel* trim3, mem_accel* trim4, mem_accel* trim5,
                 mem_accel* trim6, mem_accel* trim7)
  {
#pragma HLS INTERFACE m_axi port = keys offset = slave bundle = mem0
#pragma HLS INTERFACE m_axi port = find offset = slave bundle = mem1
#pragma HLS INTERFACE m_axi port = solutions offset = slave bundle = mem2
#pragma HLS INTERFACE m_axi port = solutions_len offset = slave bundle = mem3
#pragma HLS INTERFACE m_axi port = alive offset = slave bundle = mem4
#pragma HLS INTERFACE m_axi port = trim0 offset = slave bundle = mem_trim0
#pragma HLS INTERFACE m_axi port = trim1 offset = slave bundle = mem_trim1
#pragma HLS INTERFACE m_axi port = trim2 offset = slave bundle = mem_trim2
#pragma HLS INTERFACE m_axi port = trim3 offset = slave bundle = mem_trim3
#pragma HLS INTERFACE m_axi port = trim4 offset = slave bundle = mem_trim4
#pragma HLS INTERFACE m_axi port = trim5 offset = slave bundle = mem_trim5
#pragma HLS INTERFACE m_axi port = trim6 offset = slave bundle = mem_trim6
#pragma HLS INTERFACE m_axi port = trim7 offset = slave bundle = mem_trim7
#pragma HLS INTERFACE s_axilite port = keys bundle = control
#pragma HLS INTERFACE s_axilite port = find bundle = control
#pragma HLS INTERFACE s_axilite port = solutions bundle = control
#pragma HLS INTERFACE s_axilite port = solutions_len bundle = control
#pragma HLS INTERFACE s_axilite port = alive bundle = control
#pragma HLS INTERFACE s_axilite port = trim0 bundle = control
#pragma HLS INTERFACE s_axilite port = trim1 bundle = control
#pragma HLS INTERFACE s_axilite port = trim2 bundle = control
#pragma HLS INTERFACE s_axilite port = trim3 bundle = control
#pragma HLS INTERFACE s_axilite port = trim4 bundle = control
#pragma HLS INTERFACE s_axilite port = trim5 bundle = control
#pragma HLS INTERFACE s_axilite port = trim6 bundle = control
#pragma HLS INTERFACE s_axilite port = trim7 bundle = control
#pragma HLS INTERFACE s_axilite port = easiness bundle = control
#pragma HLS INTERFACE s_axilite port = return bundle = control
    uint32_t remains[MAX_REMAINS];
    int n_remains[1] = {easiness};
    memory_set_accel(remains, (uint32_t)0, 0, MAX_REMAINS);
    graph_accel(keys, remains, n_remains, alive, easiness, trim0, trim1, trim2, trim3, trim4, trim5, trim6, trim7);
    cycle_accel(remains, n_remains, keys, find, solutions, solutions_len);
  }
}
// ************************* function from memory.h ***************************
template <typename DataType>
void memory_set_accel(DataType* mem, DataType d, uint32_t addr, uint32_t len)
{
  for (int i = 0; i < len; i++)
    mem[addr + i] = d;
}
template <typename DataType>
void memory_read_accel(DataType* mem_src, DataType* mem_dst, uint32_t addr, uint32_t len)
{
  for (int i = 0; i < len; i++)
    mem_dst[i] = mem_src[addr + i];
}
template <typename DataType>
DataType memory_read_accel(DataType* mem, uint32_t addr)
{
  return mem[addr];
}

template <typename DataType>
void memory_write_accel(DataType* mem_src, DataType* mem_dst, uint32_t addr, uint32_t len)
{
  for (int i = 0; i < len; i++)
    mem_dst[addr + i] = mem_src[i];
}

template <typename DataType>
void memory_write_accel(DataType mem_src, DataType* mem_dst, uint32_t addr, uint32_t len)
{
  for (int i = 0; i < len; i++)
    mem_dst[addr + i] = mem_src;
}

// ******************************* function from siphash.h ************************
// ********************************************************************************
void siphash_keys_accel::setkeys(const char* keybuf)
{
  k0 = htole64(((uint64_t*)keybuf)[0]);
  k1 = htole64(((uint64_t*)keybuf)[1]);
  k2 = htole64(((uint64_t*)keybuf)[2]);
  k3 = htole64(((uint64_t*)keybuf)[3]);
}

uint64_t siphash_keys_accel::siphash24(const uint64_t nonce) const
{
  siphash_state_accel<> v(*this);
  v.hash24(nonce);
  return v.xor_lanes();
}

// **************************** function from cuckoo.h ****************************
// ********************************************************************************
// generate edge endpoint in cuckoo graph without partition bit
word_t sipnode(siphash_keys_accel keys, word_t edge, u32 uorv)
{
  return (keys.siphash24(2 * edge + uorv)) & EDGEMASK;
}
// ******************************* function from pow.h ****************************
// ********************************************************************************
u32 oddNode(u32 n, siphash_keys_accel keys)
{
  return 2 * sipnode(keys, n, 1) + 1;
}

u32 evenNode(u32 n, siphash_keys_accel keys)
{
  return 2 * sipnode(keys, n, 0);
}

Edge_Accel edge(u32 n, siphash_keys_accel keys)
{
  return Edge_Accel(evenNode(n, keys), oddNode(n, keys));
}
// ************************* function from Trim.h ***************************
void genIndex_accel(uint32_t nRemains, uint32_t* remains, uint32_t* map, remain_t* index, siphash_keys_accel keys)
{
  for (int i = 0; i < nRemains; i++)
    {
      uint32_t n;
      bool find_u, find_v;
      remain_t uIndex, vIndex;
      // remains->read(&n, i);
      n = memory_read_accel(remains, i);
      Edge_Accel e = edge(n, keys);
      //map->write(&e.u, 2 * i);
      //map->write(&e.v, 2 * i + 1);
      memory_write_accel(e.u, map, 2 * i, 1);
      memory_write_accel(e.v, map, 2 * i + 1, 1);
      find_u = false;
      find_v = false;

      for (int j = 0; j < i; j++)
        {
          word_t u, v;
          //map->read(&u, 2 * j);
          //map->read(&v, 2 * j + 1);
          u = memory_read_accel(map, 2 * j);
          v = memory_read_accel(map, 2 * j + 1);

          if (!find_u && e.u == u)
            {
              uIndex = 2 * j;
              //index->write(&uIndex, 2 * i);
              memory_write_accel(uIndex, index, 2 * i, 1);
              find_u = true;
            }

          if (!find_v && e.v == v)
            {
              vIndex = 2 * j + 1;
              //index->write(&vIndex, 2 * i + 1);
              memory_write_accel(vIndex, index, 2 * i + 1, 1);
              find_v = true;
            }

          if (find_u && find_v)
            break;
        }

      if (!find_u)
        {
          uIndex = 2 * i;
          // index->write(&uIndex, 2 * i);
          memory_write_accel(uIndex, index, 2 * i, 1);
        }

      if (!find_v)
        {
          vIndex = 2 * i + 1;
          // index->write(&vIndex, 2 * i + 1);
          memory_write_accel(vIndex, index, 2 * i + 1, 1);
        }
    }
}
Path_Accel path_accel(remain_t node, remain_t* index, remain_t* cuckoo)
{
  Path_Accel p;
  remain_t n = node;
  remain_t nIndex, nCuckoo;
  //index->read(&nIndex, n);
  nIndex = memory_read_accel(index, n);

  while (nIndex < (1 << (sizeof(remain_t) * 8 - 1)))
    {
      p.add(nIndex);
      //cuckoo->read(&nIndex, nIndex);
      nIndex = memory_read_accel(cuckoo, nIndex);
    }

  return p;
}
Path_Accel genCycle_accel(Path_Accel pu, Path_Accel pv, uint32_t nRemains, remain_t* index, uint32_t* map)
{
  Path_Accel cycle;
  int min = pu.size() < pv.size() ? pu.size() : pv.size();
  int u = pu.size() - min;
  int v = pv.size() - min;

  while (pu.value(u) != pv.value(v))
    {
      u++;
      v++;
    }

  for (int i = 0; i < u; i++)
    {
      word_t node;

      for (int j = 0; j < nRemains; j++)
        {
          remain_t nIndex;
          uint32_t k = i & 1 ? 2 * j + 1 : 2 * j;
          //index->read(&nIndex, k);
          nIndex = memory_read_accel(index, k);

          if (nIndex == pu.value(i))
            {
              //map->read(&node, k);
              node = memory_read_accel(map, k);
              break;
            }
        }

      cycle.add(node);
    }

  for (int i = v; i >= 0; i--)
    {
      word_t node;

      for (int j = 0; j < nRemains; j++)
        {
          remain_t nIndex;
          uint32_t k = i & 1 ? 2 * j : 2 * j + 1;
          //index->read(&nIndex, k);
          nIndex = memory_read_accel(index, k);

          if (nIndex == pv.value(i))
            {
              //map->read(&node, k);
              node = memory_read_accel(map, k);
              break;
            }
        }

      cycle.add(node);
    }

  // LOG_I("detect cycle size = %d", cycle.size());
  // std::cout << "hw detect cycle size =" << cycle.size() << std::endl;
  return cycle;
}
// ******************************* function from Path.h ************************
// ********************************************************************************
void Path_Accel::add(u32 node)
{
#ifdef VECTOR
  path.push_back(node);
#else
  path[len++] = node;
#endif
}

u32 Path_Accel::tail()
{
#ifdef VECTOR
  return path.back();
#else
  return path[len - 1];
#endif
}

int Path_Accel::size()
{
#ifdef VECTOR
  return path.size();
#else
  return len;
#endif
}

u32 Path_Accel::value(int i)
{
#ifdef VECTOR
  return path.at(i);
#else
  return path[i];
#endif
}

bool Path_Accel::find(Edge_Accel e)
{
  if (size() % 2 != 0)
    std::cout << "error size" << std::endl;

  int start = value(0) % 2 == 0 ? 0 : 1;
  int i = start;

  do
    {
      int left = (i + size() - 1) % size();
      int right = (i + 1) % size();

      if (value(i) == e.u && (value(left) == e.v || value(right) == e.v))
        return true;

      i = (i + 2) % size();
    }
  while (i != start);

  return false;
}

void trim_init(mem_accel* trim0, mem_accel* trim1, mem_accel* trim2, mem_accel* trim3, mem_accel* trim4,
               mem_accel* trim5,
               mem_accel* trim6, mem_accel* trim7)
{
#pragma HLS loop_merge

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim0[i] = (mem_accel)0;

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim1[i] = (mem_accel)0;

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim2[i] = (mem_accel)0;

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim3[i] = (mem_accel)0;

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim4[i] = (mem_accel)0;

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim5[i] = (mem_accel)0;

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim6[i] = (mem_accel)0;

  for (int i = 0; i < CHANNEL_NCUCKOO / WIDTH_ACCEL * 8; i++)
    trim7[i] = (mem_accel)0;
}
