#include "xcl2.hpp"
#include <algorithm>


#include "Trim.h"
#include "pow_accel.h"
using namespace std;
using namespace tensorchip;


static mem_accel trim[CHANNEL_NUM][NCUCKOO / WIDTH_ACCEL * 8 / CHANNEL_NUM];
static mem_accel alive[(EASINESS + WIDTH_ACCEL - 1) / WIDTH_ACCEL];

#define TEST_MODE 0

int main(int argc, char** argv)
{
  if (argc != 2)
    {
      std::cout << "Usage: " << argv[0] << " <XCLBIN File>" << std::endl;
      return EXIT_FAILURE;
    }

  u32 nonce = 0;
// for cpu compute
  char header_sw[HEADERLEN];
  memset(header_sw, 0, HEADERLEN);
  Trim* pow = new Trim(header_sw, EASIPCT);
  int easiness = EASINESS;
  // hw prepare
  uint64_t siphash_keys[4];
  memset(siphash_keys, 0, 32);

  //memset(trim, 0, NCUCKOO * sizeof(uint8_t));
  for (int i = 0; i < CHANNEL_NUM; i++)
    memset(trim[i], 0, 8 * NCUCKOO / WIDTH_ACCEL * sizeof(mem_accel) / CHANNEL_NUM);

  uint32_t find[1] = {0};
  uint32_t solutions_hw[SOLUTIONS_SIZE][PROOFSIZE];
  uint16_t solutions_len[1] = {0};
  memset(solutions_hw, 0, SOLUTIONS_SIZE * PROOFSIZE * sizeof(uint32_t));
  cout << "start software reset" << endl;
  pow->reset(nonce);
  siphash_keys[0] = pow->sip_keys.k0;
  siphash_keys[1] = pow->sip_keys.k1;
  siphash_keys[2] = pow->sip_keys.k2;
  siphash_keys[3] = pow->sip_keys.k3;
  cout << "sip keys assignment and start run" << endl;
  std::string binaryFile = argv[1];
  cl_int err;
  // OPENCL HOST CODE AREA START
  auto devices = xcl::get_xil_devices();
  auto device = devices[0];
  OCL_CHECK(err, cl::Context context(device, NULL, NULL, NULL, &err));
  OCL_CHECK(err, cl::CommandQueue q(context, device, CL_QUEUE_PROFILING_ENABLE, &err));
  // read_binary_file() is a utility API which will load the binaryFile
  auto fileBuf = xcl::read_binary_file(binaryFile);
  cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
  devices.resize(1);
  OCL_CHECK(err, cl::Program program(context, devices, bins, NULL, &err));
  // Allocate Buffer in Global Memory
  cout << "****** Allocate Buffer in Global Memory ******" << endl;
  OCL_CHECK(err,
            cl::Buffer buffer_alive(context,
                                    CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                    //(easiness + 7) / 8 * sizeof(mem_t),
                                    (EASINESS + WIDTH - 1) / WIDTH * sizeof(mem_t),
                                    alive,
                                    &err));
  OCL_CHECK(err,
            cl::Buffer buffer_keys(context,
                                   CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                   4 * sizeof(uint64_t),
                                   siphash_keys,
                                   &err));
  /*OCL_CHECK(err,
            cl::Buffer buffer_trim(context,
                                   CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                   NCUCKOO * sizeof(uint8_t),
                                   trim,
                                   &err));*/
  std::vector<cl::Buffer> buffer_trim(CHANNEL_NUM);

  for (int i = 0; i < CHANNEL_NUM; i++)
    {
      OCL_CHECK(err, buffer_trim[i] = cl::Buffer(context, CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      NCUCKOO / WIDTH_ACCEL * sizeof(mem_accel) * 8 / CHANNEL_NUM,
                                      trim[i], &err));
    }

  OCL_CHECK(err,
            cl::Buffer buffer_find(context,
                                   CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                   1 * sizeof(bool),
                                   find,
                                   &err));
  OCL_CHECK(err,
            cl::Buffer buffer_solutions(context,
                                        CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                        SOLUTIONS_SIZE * PROOFSIZE * sizeof(uint32_t),
                                        solutions_hw,
                                        &err));
  OCL_CHECK(err,
            cl::Buffer buffer_solutions_len(context,
                CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                1 * sizeof(uint16_t),
                solutions_len,
                &err));
  cout << "****** kernel args set ******" << endl;
  OCL_CHECK(err, cl::Kernel krnl_graph_accel(program, "pow_accel", &err));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(0, buffer_keys));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(1, buffer_find));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(2, buffer_solutions));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(3, buffer_solutions_len));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(4, buffer_alive));
  //OCL_CHECK(err, err = krnl_graph_accel.setArg(5, buffer_trim));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(5, easiness));

  for (int i = 0; i < CHANNEL_NUM; i++)
    OCL_CHECK(err, err = krnl_graph_accel.setArg(i + 6, buffer_trim[i]));

  // Copy input data to device global memory
  cout << "****** copy input data to device global memory ******" << endl;
  auto start = chrono::system_clock::now();
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({buffer_keys},
                  0 /* 0 means from host*/));
  // Launch the Kernel
  cout << "****** Launch the Kernel ******" << endl;
  OCL_CHECK(err, err = q.enqueueTask(krnl_graph_accel));
  // Copy Result from Device Global Memory to Host Local Memory
  cout << "****** Copy Result from Device Global Memory to Host Local Memory ******" << endl;
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({buffer_find, buffer_solutions, buffer_solutions_len},
                  CL_MIGRATE_MEM_OBJECT_HOST));
  cout << "****** prepare finishing the kernel ******" << endl;
  OCL_CHECK(err, err = q.finish());
  auto end = chrono::system_clock::now();
  std::chrono::duration<double> diff = end - start;
  cout << "Time elipsed in Device is " << diff.count() << endl;
  // OPENCL HOST CODE AREA END
  cout << "****** prepare cpu running ******" << endl;
  pow->run();
  cout << "finish running" << endl;
  // Compare the results of the Device to the simulation
  std::cout << "**************** start pow function validation ***************" << std::endl;
  Path solutions[SOLUTIONS_SIZE];
  bool match_find = true;
  bool match_solution = true;

  if (find[0] == 1 && pow->solutions.empty() == false)
    {
      for (int i = 0; i < solutions_len[0]; i++)
        {
          for (int j = 0; j < PROOFSIZE; j++)
            solutions[i].add(solutions_hw[i][j]);

          int stats = pow->verify(pow->genSolution(solutions[i]));

          if (stats != 0)
            {
              std::cout << "hw find solution[" << i << "] is error,state code = " << stats << std::endl;
              match_solution = false;
            }

          int stats_sw = pow->verify(pow->genSolution(pow->solutions[i]));

          if (stats_sw != 0)
            {
              std::cout << "sw find solution[" << i << "] is error,state code = " << stats_sw << std::endl;
              match_solution = false;
            }
        }

      if (match_solution)std::cout << "Success:hw find solution and sw find solution pass verify" << std::endl;
    }
  else if (find[0] == 0 && pow->solutions.empty() == true)
    std::cout << "Success:hw not find solution and sw not find" << std::endl;
  else
    {
      std::cout << "Error:find result not match" << std::endl;
      match_find = false;
    }

  std::cout << " ****** Pow Test " << ((match_find & match_solution) ? "PASSED" : "FAILED") << " ******" << std::endl;
  return ((match_find & match_solution) ? EXIT_SUCCESS : EXIT_FAILURE);
}
