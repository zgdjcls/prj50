#include "cycle_accel.h"

extern "C" {
  void cycle_accel(bool* find, uint32_t solutions[SOLUTIONS_SIZE][PROOFSIZE], uint16_t* solutions_len, uint32_t* remains,
                   int* n_remains, uint64_t* keys)
  {
#pragma HLS INTERFACE m_axi port = remains offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = keys offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = n_remains offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = find offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = solutions offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = solutions_len offset = slave bundle = gmem
#pragma HLS INTERFACE s_axilite port = remains bundle = control
#pragma HLS INTERFACE s_axilite port = n_remains bundle = control
#pragma HLS INTERFACE s_axilite port = keys bundle = control
#pragma HLS INTERFACE s_axilite port = find bundle = control
#pragma HLS INTERFACE s_axilite port = solutions bundle = control
#pragma HLS INTERFACE s_axilite port = solutions_len bundle = control
#pragma HLS INTERFACE s_axilite port = return bundle = control
    siphash_keys_accel sip_keys;
    sip_keys.k0 = keys[0];
    sip_keys.k1 = keys[1];
    sip_keys.k2 = keys[2];
    sip_keys.k3 = keys[3];
    uint32_t nRemains = n_remains[0];
    uint32_t remains_buffer[MAX_REMAINS * 2];

    for (int i = 0; i < nRemains; i++)
      {
#pragma HLS pipeline II=1
        remains_buffer[i] = remains[i];
      }

    remain_t cuckoo_buffer[MAX_REMAINS * 2];
#pragma HLS dependence variable=cuckoo_buffer inter false
    uint32_t map_buffer_u[MAX_REMAINS];
    uint32_t map_buffer_v[MAX_REMAINS];
    remain_t index_buffer_u[MAX_REMAINS];
    remain_t index_buffer_v[MAX_REMAINS];
    uint32_t solutions_buffer[SOLUTIONS_SIZE][PROOFSIZE];
    uint16_t solutions_len_buffer = 0;
    bool find_buff = false;
// ****************** funcion body of cycle ******************
    Path_Accel pu, pv;
#pragma HLS dependence variable=pu inter false
#pragma HLS dependence variable=pv inter false
    genIndex_accel(nRemains, remains_buffer, map_buffer_u, map_buffer_v, index_buffer_u, index_buffer_v, sip_keys);
    memory_set_accel(cuckoo_buffer, (remain_t) -1, 0, MAX_REMAINS * 2);
loop_nRemains:

    for (int i = 0; i < nRemains; i++)
      {
#pragma HLS pipeline II=1
        path_accel(i, index_buffer_u, cuckoo_buffer, &pu);
        path_accel(i, index_buffer_v, cuckoo_buffer, &pv);

        if (pu.tail() == pv.tail())
          {
            // Cycle found
            Path_Accel cycle = genCycle_accel(pu, pv, nRemains, index_buffer_u, index_buffer_v, map_buffer_u, map_buffer_v);

            if (cycle.size() == PROOFSIZE)
              {
                std::cout << "****************solution found***************" << std::endl;
loop_for_find_solutions:

                for (int i = 0; i < PROOFSIZE; i++)
#pragma HLS pipeline II=1
                  solutions_buffer[solutions_len_buffer][i] = cycle.value(i);

                solutions_len_buffer++;
                find_buff = true;
              }

#if defined(DEBUG) && defined(VERIFY)
            int ret = verify(genSolution(cycle));

	  // *INDENT-OFF*
	  if (ret == POW_OK)
	    {
	      LOG_I("Solution verified");
	    }
	  else
	    {
	      LOG_F("Solution error with code=%d", ret);
	    }
	  // *INDENT-ON*
#endif
          }
        else
          {
            // Join path
            if (pu.size() < pv.size())
              {
                // revert path u
loop_for_revert_path_u:

                for (int i = pu.size() - 1; i > 0; i--)
                  {
#pragma HLS pipeline II=1
                    remain_t tmp = pu.value(i - 1);
                    memory_write_accel(tmp, cuckoo_buffer, pu.value(i), 1);
                  }

                //LOG_LOCATION;
                remain_t nIndex, nCuckoo;
                nIndex = memory_read_accel(index_buffer_v, i);
                nCuckoo = memory_read_accel(cuckoo_buffer, nIndex);
                memory_write_accel(nIndex, cuckoo_buffer, pu.value(0), 1);
              }
            else
              {
                // revert path v
loop_for_revert_path_v:

                for (int i = pv.size() - 1; i > 0; i--)
                  {
#pragma HLS pipeline II=1
                    remain_t tmp = pv.value(i - 1);
                    memory_write_accel(tmp, cuckoo_buffer, pv.value(i), 1);
                  }

                //LOG_LOCATION;
                remain_t nIndex, nCuckoo;
                nIndex = memory_read_accel(index_buffer_u, i);
                nCuckoo = memory_read_accel(cuckoo_buffer, nIndex);
                memory_write_accel(nIndex, cuckoo_buffer, pv.value(0), 1);
              }
          }
      }

    // ************************* data output **************************************
    if (find_buff == true)
      {
loop_write_solutions:

        for (int i = 0; i < solutions_len_buffer; i++)
loop_write_solutions_proofsize :
          for (int j = 0; j < PROOFSIZE; j++)
#pragma HLS pipeline II=1
            solutions[i][j] = solutions_buffer[i][j];

        *solutions_len = solutions_len_buffer;
      }

    *find = find_buff;
  }
}
// ************************* function from Trim.h ***************************
void genIndex_accel(uint32_t nRemains, uint32_t* remains, uint32_t* map_u, uint32_t* map_v, remain_t* index_u,
                    remain_t* index_v,
                    siphash_keys_accel keys)
{
  for (int i = 0; i < nRemains; i++)
    {
#pragma HLS pipeline II=1
      uint32_t n;
      n = memory_read_accel(remains, i);
      Edge_Accel e = edge(n, keys);
      genIndex_dataflow(e.u, e.v, i, map_u, map_v, index_u, index_v);
    }
}
void genIndex_dataflow(u32 eu, u32 ev, int i, uint32_t* map_u, uint32_t* map_v, remain_t* index_u, remain_t* index_v)
{
#pragma HLS DATAFLOW
  genIndex_unroll_u(eu, i, map_u, index_u);
  genIndex_unroll_v(ev, i, map_v, index_v);
}

void genIndex_unroll_u(u32 eu, int i, uint32_t* map_u, remain_t* index_u)
{
#pragma HLS INLINE off
  memory_write_accel(eu, map_u, i, 1);
  remain_t uIndex;
  bool find_u;
  find_u = false;

  for (int j = 0; j < i; j++)
    {
#pragma HLS pipeline II=1
      word_t u;
      u = memory_read_accel(map_u, j);

      if (!find_u && eu == u)
        {
          uIndex = 2 * j;
          memory_write_accel(uIndex, index_u, i, 1);
          find_u = true;
          break;
        }
    }

  if (!find_u)
    {
      uIndex = 2 * i;
      memory_write_accel(uIndex, index_u, i, 1);
    }
}
void genIndex_unroll_v(u32 ev, int i, uint32_t* map_v, remain_t* index_v)
{
#pragma HLS INLINE off
  memory_write_accel(ev, map_v, i, 1);
  remain_t vIndex;
  bool find_v;
  find_v = false;

  for (int j = 0; j < i; j++)
    {
#pragma HLS pipeline II=1
      word_t v;
      v = memory_read_accel(map_v, j);

      if (!find_v && ev == v)
        {
          vIndex = 2 * j + 1;
          memory_write_accel(vIndex, index_v, i, 1);
          find_v = true;
          break;
        }
    }

  if (!find_v)
    {
      vIndex = 2 * i + 1;
      memory_write_accel(vIndex, index_v, i, 1);
    }
}
void path_accel(remain_t node, remain_t* index, remain_t* cuckoo, Path_Accel* path)
{
#pragma HLS FUNCTION_INSTANTIATE variable=path
#pragma HLS INLINE off
  path->reset();
  remain_t n = node;
  remain_t nIndex, nCuckoo;
  nIndex = memory_read_accel(index, n);
loop_path_accel:

  while (nIndex < (1 << (sizeof(remain_t) * 8 - 1)))
    {
#pragma HLS PIPELINE II=1
      path->add(nIndex);
      nIndex = memory_read_accel(cuckoo, nIndex);
    }
}
Path_Accel genCycle_accel(Path_Accel pu, Path_Accel pv, uint32_t nRemains, remain_t* index_u, remain_t* index_v,
                          uint32_t* map_u, uint32_t* map_v)
{
  Path_Accel cycle;
  int min = pu.size() < pv.size() ? pu.size() : pv.size();
  int u = pu.size() - min;
  int v = pv.size() - min;
loop_gencycle_accel_pu_pv_while:

  while (pu.value(u) != pv.value(v))
    {
      u++;
      v++;
    }

loop_gencycle_accel_i_u:

  for (int i = 0; i < u; i++)
    {
#pragma HLS PIPELINE
      word_t node;
loop_gencycle_accel_j_nRemains_u:

      for (int j = 0; j < nRemains; j++)
        {
#pragma HLS pipeline II=1
          remain_t nIndex;
          nIndex = i & 1 ?  memory_read_accel(index_v, j) : memory_read_accel(index_u, j);

          if (nIndex == pu.value(i))
            {
              node = i & 1 ? memory_read_accel(map_v, j) : memory_read_accel(map_u, j);
              break;
            }
        }

      cycle.add(node);
    }

loop_gencycle_accel_i_v:

  for (int i = v; i >= 0; i--)
    {
#pragma HLS PIPELINE
      word_t node;
loop_gencycle_accel_j_nRemains_v:

      for (int j = 0; j < nRemains; j++)
        {
#pragma HLS pipeline II=1
          remain_t nIndex;
          uint32_t k = i & 1 ? 2 * j : 2 * j + 1;
          nIndex = i & 1 ?  memory_read_accel(index_u, j) : memory_read_accel(index_v, j);

          if (nIndex == pv.value(i))
            {
              node = i & 1 ? memory_read_accel(map_u, j) : memory_read_accel(map_v, j);
              break;
            }
        }

      cycle.add(node);
    }

  return cycle;
}
// ******************************* function from Path.h ************************
// ********************************************************************************
void Path_Accel::reset()
{
#ifdef VECTOR
  path.clear();
#else
  len = 0;
#endif
}
void Path_Accel::add(u32 node)
{
#ifdef VECTOR
  path.push_back(node);
#else
  path[len++] = node;
#endif
}

u32 Path_Accel::tail()
{
#ifdef VECTOR
  return path.back();
#else
  return path[len - 1];
#endif
}

int Path_Accel::size()
{
#ifdef VECTOR
  return path.size();
#else
  return len;
#endif
}

u32 Path_Accel::value(int i)
{
#ifdef VECTOR
  return path.at(i);
#else
  return path[i];
#endif
}

bool Path_Accel::find(Edge_Accel e)
{
  if (size() % 2 != 0)
    std::cout << "error size" << std::endl;

  int start = value(0) % 2 == 0 ? 0 : 1;
  int i = start;
Path_Accel_find_do:

  do
    {
      int left = (i + size() - 1) % size();
      int right = (i + 1) % size();

      if (value(i) == e.u && (value(left) == e.v || value(right) == e.v))
        return true;

      i = (i + 2) % size();
    }
  while (i != start);

  return false;
}
// ************************* function from memory.h ***************************
template <typename DataType>
void memory_set_accel(DataType* mem, DataType d, uint32_t addr, uint32_t len)
{
memory_set_accel_loop:

  for (int i = 0; i < len; i++)
#pragma HLS PIPELINE
    mem[addr + i] = d;
}
//memcpy (void *__restrict __dest, const void *__restrict __src
template <typename DataType>
DataType memory_read_accel(DataType* mem, uint32_t addr)
{
  return mem[addr];
}
template <typename DataType>
void memory_write_accel(DataType mem_src, DataType* mem_dst, uint32_t addr, uint32_t len)
{
memory_write_accel_loop:

  for (int i = 0; i < len; i++)
#pragma HLS PIPELINE
    mem_dst[addr + i] = mem_src;
}
// ******************************* function from siphash.h ************************
// ********************************************************************************
void siphash_keys_accel::setkeys(const char* keybuf)
{
  k0 = htole64(((uint64_t*)keybuf)[0]);
  k1 = htole64(((uint64_t*)keybuf)[1]);
  k2 = htole64(((uint64_t*)keybuf)[2]);
  k3 = htole64(((uint64_t*)keybuf)[3]);
}

uint64_t siphash_keys_accel::siphash24(const uint64_t nonce) const
{
  siphash_state_accel<> v(*this);
  v.hash24(nonce);
  return v.xor_lanes();
}

// **************************** function from cuckoo.h ****************************
// ********************************************************************************
// generate edge endpoint in cuckoo graph without partition bit
word_t sipnode(siphash_keys_accel keys, word_t edge, u32 uorv)
{
  return (keys.siphash24(2 * edge + uorv)) & EDGEMASK;
}
// ******************************* function from pow.h ****************************
// ********************************************************************************
u32 oddNode(u32 n, siphash_keys_accel keys)
{
  return 2 * sipnode(keys, n, 1) + 1;
}

u32 evenNode(u32 n, siphash_keys_accel keys)
{
  return 2 * sipnode(keys, n, 0);
}

Edge_Accel edge(u32 n, siphash_keys_accel keys)
{
  return Edge_Accel(evenNode(n, keys), oddNode(n, keys));
}
