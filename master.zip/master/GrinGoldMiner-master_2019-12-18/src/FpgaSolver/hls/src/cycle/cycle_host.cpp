#include "xcl2.hpp"
#include <algorithm>


#include "Trim.h"
#include "cycle_accel.h"
using namespace std;
using namespace tensorchip;

int main(int argc, char** argv)
{
  if (argc != 2)
    {
      std::cout << "Usage: " << argv[0] << " <XCLBIN File>" << std::endl;
      return EXIT_FAILURE;
    }

  u32 nonce = 0;
  int easipct = EASIPCT;
// for cpu compute
  char header_sw[HEADERLEN];
  memset(header_sw, 0, HEADERLEN);
  Trim* pow = new Trim(header_sw, easipct);
  int easiness = EASINESS;
  // hw prepare
  int n_remains[1] = {easiness};
  uint64_t siphash_keys[4];
  memset(siphash_keys, 0, 32);
  uint32_t remains[MAX_REMAINS];
  memset(remains, 0, MAX_REMAINS * sizeof(uint32_t));
  bool find[1] = {false};
  uint32_t solutions_hw[SOLUTIONS_SIZE][PROOFSIZE];
  uint16_t solutions_len[1] = {0};
  memset(solutions_hw, 0, SOLUTIONS_SIZE * PROOFSIZE * sizeof(uint32_t));
  pow->reset(nonce);
  pow->run();
  siphash_keys[0] = pow->sip_keys.k0;
  siphash_keys[1] = pow->sip_keys.k1;
  siphash_keys[2] = pow->sip_keys.k2;
  siphash_keys[3] = pow->sip_keys.k3;

  for (int i = 0; i < MAX_REMAINS; i++)
    remains[i] = (pow->remains->mem)[i];

  n_remains[0] = pow->nRemains;
  std::string binaryFile = argv[1];
  cl_int err;
  // OPENCL HOST CODE AREA START
  // get_xil_devices() is a utility API which will find the xilinx
  // platforms and will return list of devices connected to Xilinx platform
  auto devices = xcl::get_xil_devices();
  auto device = devices[0];
  OCL_CHECK(err, cl::Context context(device, NULL, NULL, NULL, &err));
  OCL_CHECK(
    err,
    cl::CommandQueue q(context, device, CL_QUEUE_PROFILING_ENABLE, &err));
  // read_binary_file() is a utility API which will load the binaryFile
  // and will return the pointer to file buffer.
  auto fileBuf = xcl::read_binary_file(binaryFile);
  cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
  devices.resize(1);
  OCL_CHECK(err, cl::Program program(context, devices, bins, NULL, &err));
  // Allocate Buffer in Global Memory
  // Buffers are allocated using CL_MEM_USE_HOST_PTR for efficient memory and
  // Device-to-host communication
  //cout<<"****** Allocate Buffer in Global Memory ******"<<endl;
  OCL_CHECK(err,
            cl::Buffer buffer_find(context,
                                   CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                   1 * sizeof(bool),
                                   find,
                                   &err));
  OCL_CHECK(err,
            cl::Buffer buffer_solutions(context,
                                        CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                        SOLUTIONS_SIZE * PROOFSIZE * sizeof(uint32_t),
                                        solutions_hw,
                                        &err));
  OCL_CHECK(err,
            cl::Buffer buffer_solutions_len(context,
                CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                1 * sizeof(uint16_t),
                solutions_len,
                &err));
  OCL_CHECK(err,
            cl::Buffer buffer_remains(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      MAX_REMAINS * sizeof(uint32_t),
                                      remains,
                                      &err));
  OCL_CHECK(err,
            cl::Buffer buffer_keys(context,
                                   CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                   4 * sizeof(uint64_t),
                                   siphash_keys,
                                   &err));
  OCL_CHECK(err,
            cl::Buffer buffer_n_remains(context,
                                        CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                        1 * sizeof(int),
                                        n_remains,
                                        &err));
  //cout<<"****** kernel args set ******"<<endl;
  OCL_CHECK(err, cl::Kernel krnl_cycle_accel(program, "cycle_accel", &err));
  OCL_CHECK(err, err = krnl_cycle_accel.setArg(0, buffer_find));
  OCL_CHECK(err, err = krnl_cycle_accel.setArg(1, buffer_solutions));
  OCL_CHECK(err, err = krnl_cycle_accel.setArg(2, buffer_solutions_len));
  OCL_CHECK(err, err = krnl_cycle_accel.setArg(3, buffer_remains));
  OCL_CHECK(err, err = krnl_cycle_accel.setArg(4, buffer_n_remains));
  OCL_CHECK(err, err = krnl_cycle_accel.setArg(5, buffer_keys));
  // Copy input data to device global memory
  auto start = chrono::system_clock::now();
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({buffer_remains, buffer_n_remains, buffer_keys},
                  0 /* 0 means from host*/));
  // Launch the Kernel
  // For HLS kernels global and local size is always (1,1,1). So, it is recommended
  // to always use enqueueTask() for invoking HLS kernel
  //cout<<"****** Launch the Kernel ******"<<endl;
  OCL_CHECK(err, err = q.enqueueTask(krnl_cycle_accel));
  // Copy Result from Device Global Memory to Host Local Memory
  //cout<<"****** Copy Result from Device Global Memory to Host Local Memory ******"<<endl;
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({buffer_find, buffer_solutions, buffer_solutions_len},
                  CL_MIGRATE_MEM_OBJECT_HOST));
  //cout<<"****** prepare finishing the kernel ******"<<endl;
  OCL_CHECK(err, err = q.finish());
  auto end = chrono::system_clock::now();
  std::chrono::duration<double> diff = end - start;
  cout << "Time elipsed in Device is " << diff.count() << endl;
  // OPENCL HOST CODE AREA END
  //cout<<"****** prepare cpu running ******"<<endl;
  //pow->run();
  //cout << "finish running" << endl;
  // Compare the results of the Device to the simulation
  bool match = true;
  bool match_solutions = true;

  if (pow->solutions.empty() and find[0] == false)
    std::cout << "cpu not find and hw not find. Success: Result match " << std::endl;
  else if (pow->solutions.empty() == false and find[0])
    {
      std::cout << "cou find and hw find. Success: Result match " << std::endl;
      std::cout << "solutions_len=" << solutions_len[0] << std::endl;

      for (int i = 0; i < solutions_len[0]; i++)
        {
          for (int j = 0; j < PROOFSIZE; j++)
            {
              if (pow->solutions[i].value(j) != solutions_hw[i][j])
                {
                  std::cout << "i,j=" << i << ',' << j << "; hw=" << pow->solutions[i].value(j) << "; sw=" << solutions_hw[i][j] <<
                            std::endl;
                  std::cout << "Error: Result solutions mismatch " << std::endl;
                  match_solutions = false;
                }
            }
        }

      if (match_solutions)std::cout << "Success: Result solutions match  " << std::endl;
    }
  else
    {
      std::cout << "find[0]=" << find[0] << std::endl;
      std::cout << "pow->solutions.empty()=" << pow->solutions.empty() << std::endl;
      std::cout << "Error: Result mismatch " << std::endl;
      match = false;;
    }

  std::cout << "Reset Test " << ((match & match_solutions) ? "PASSED" : "FAILED")
            << std::endl;
  return (match ? EXIT_SUCCESS : EXIT_FAILURE);
}


