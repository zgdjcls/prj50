#include "xcl2.hpp"
#include <algorithm>


#include "Trim.h"
#include "accel.h"
using namespace std;
using namespace tensorchip;

int main(int argc, char** argv)
{
  if (argc != 2)
    {
      std::cout << "Usage: " << argv[0] << " <XCLBIN File>" << std::endl;
      return EXIT_FAILURE;
    }

  char header[HEADERLEN];
  uint64_t siphash_keys_hw[4];
  memset(header, 0, HEADERLEN);
  memset(siphash_keys_hw, 0, 32);
  u32 nonce = 0;
// for cpu compute
  char header_sw[HEADERLEN];
  uint64_t siphash_keys[4];
  memset(header_sw, 0, HEADERLEN);
  memset(siphash_keys, 0, 32);
  bool match = true;
  Pow* pow = (Pow*)(new Trim(header_sw));
  std::string binaryFile = argv[1];
  cl_int err;
  // OPENCL HOST CODE AREA START
  // get_xil_devices() is a utility API which will find the xilinx
  // platforms and will return list of devices connected to Xilinx platform
  auto devices = xcl::get_xil_devices();
  auto device = devices[0];
  OCL_CHECK(err, cl::Context context(device, NULL, NULL, NULL, &err));
  OCL_CHECK(
    err,
    cl::CommandQueue q(context, device, CL_QUEUE_PROFILING_ENABLE, &err));
  // read_binary_file() is a utility API which will load the binaryFile
  // and will return the pointer to file buffer.
  auto fileBuf = xcl::read_binary_file(binaryFile);
  cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
  devices.resize(1);
  OCL_CHECK(err, cl::Program program(context, devices, bins, NULL, &err));
  // Allocate Buffer in Global Memory
  // Buffers are allocated using CL_MEM_USE_HOST_PTR for efficient memory and
  // Device-to-host communication
  OCL_CHECK(err,
            cl::Buffer buffer_in1(context,
                                  CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                  HEADERLEN * sizeof(char),
                                  header,
                                  &err));
  OCL_CHECK(err,
            cl::Buffer buffer_output(context,
                                     CL_MEM_USE_HOST_PTR | CL_MEM_WRITE_ONLY,
                                     4 * sizeof(uint64_t),
                                     siphash_keys_hw,
                                     &err));
  OCL_CHECK(err, cl::Kernel krnl_reset_accel(program, "reset_accel", &err));
  OCL_CHECK(err, err = krnl_reset_accel.setArg(0, buffer_in1));
  OCL_CHECK(err, err = krnl_reset_accel.setArg(1, nonce));
  OCL_CHECK(err, err = krnl_reset_accel.setArg(2, buffer_output));
  // Copy input data to device global memory
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({buffer_in1},
                  0 /* 0 means from host*/));
  // Launch the Kernel
  // For HLS kernels global and local size is always (1,1,1). So, it is recommended
  // to always use enqueueTask() for invoking HLS kernel
  OCL_CHECK(err, err = q.enqueueTask(krnl_reset_accel));
  // Copy Result from Device Global Memory to Host Local Memory
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({buffer_output},
                  CL_MIGRATE_MEM_OBJECT_HOST));
  q.finish();
  // OPENCL HOST CODE AREA END
  // cout << "start reset" << endl;
  pow->reset(nonce);
  siphash_keys[0] = pow->sip_keys.k0;
  siphash_keys[1] = pow->sip_keys.k1;
  siphash_keys[2] = pow->sip_keys.k2;
  siphash_keys[3] = pow->sip_keys.k3;
  // cout << "sip keys assignment and start run" << endl;
  pow->run();
  // cout << "finish running" << endl;
  // Compare the results of the Device to the simulation
  // std::cout << "**************** start reset function validation ***************" << std::endl;
  match = true;

  for (int i = 0; i < 4; i++)
    {
      if (siphash_keys[i] != siphash_keys_hw[i])
        {
          std::cout << "Error: Result mismatch ";
          std::cout << hex << "i = " << i << " CPU result = " << siphash_keys[i]
                    << " Device result = " << siphash_keys_hw[i]
                    << std::endl;
          match = false;
          //break;
        }
      else
        {
          std::cout << "Success: Result match ";
          std::cout << hex << "i = " << i << " CPU result = " << siphash_keys[i]
                    << " Device result = " << siphash_keys_hw[i]
                    << std::endl;
        }
    }

  std::cout << "Reset Test " << (match ? "PASSED" : "FAILED") << std::endl;
  return (match ? EXIT_SUCCESS : EXIT_FAILURE);
}


