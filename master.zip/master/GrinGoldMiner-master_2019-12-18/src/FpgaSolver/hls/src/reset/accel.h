#ifndef _ACCEL_H_
#define _ACCEL_H_

#include "macro_accel.h"
#include "crypto/portable_endian.h"    // for htole32/64
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include <stddef.h>
#include <ap_int.h>
#include <iostream>

// ***********************************************

// convenience function for extracting siphash keys from header
void setheader_accel(const char* header, const u32 headerlen, uint64_t siphash_keys[4]);

// set siphash keys from 32 byte char array
void setkeys_accel(const char* keybuf, uint64_t siphash_keys[4]);

// *****************************************************
// ******************* blake.h **************************
#if defined(_MSC_VER)
#define BLAKE2_PACKED(x) __pragma(pack(push, 1)) x __pragma(pack(pop))
#else
#define BLAKE2_PACKED(x) x __attribute__((packed))
#endif

#if defined(__cplusplus)
extern "C" {
#endif

/* Streaming API */

int blake2b_init(blake2b_state* S, size_t outlen);
int blake2b_init_param(blake2b_state* S, const blake2b_param* P);
int blake2b_update(blake2b_state* S, const void* in, size_t inlen);
int blake2b_final(blake2b_state* S, void* out, size_t outlen);

/* Simple API */
int blake2b(void* out, size_t outlen, const void* in, size_t inlen, const void* key, size_t keylen);


#if defined(__cplusplus)
}
#endif

#endif
