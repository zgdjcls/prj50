#include "accel_graph.h"

extern "C" {
  void graph_accel(mem_t* alive, uint32_t* remains, uint64_t* keys, uint8_t* trim, int easiness, int* n_remains)
  {
#pragma HLS INTERFACE m_axi port = alive offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = keys offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = remains offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = trim offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = n_remains offset = slave bundle = gmem
#pragma HLS INTERFACE s_axilite port = n_remains bundle = control
#pragma HLS INTERFACE s_axilite port = alive bundle = control
#pragma HLS INTERFACE s_axilite port = keys bundle = control
#pragma HLS INTERFACE s_axilite port = remains bundle = control
#pragma HLS INTERFACE s_axilite port = trim bundle = control
#pragma HLS INTERFACE s_axilite port = easiness bundle = control
#pragma HLS INTERFACE s_axilite port = return bundle = control
    siphash_keys_accel sip_keys;
    sip_keys.k0 = keys[0];
    sip_keys.k1 = keys[1];
    sip_keys.k2 = keys[2];
    sip_keys.k3 = keys[3];
    int round = 0;
    int trimed = easiness, remain = easiness;
    mem_t alive_cache[ALIVE_CACHE_SIZE];
    uint32_t remains_buffer[REMAINS_CACHE_SIZE];
    uint32_t nRemains = 0;
// ****************** funcion body of graph ******************
// ******* alive DDR initialization **********
    memory_set_accel(alive, (mem_t)(-1), 0, (easiness + 7) / 8);

// ***************************************
    while (remain > MAX_REMAINS)
      {
        round++;
        // Init cuckoo (reused as counter in trim phase) to 0
        memory_set_accel(trim, (uint8_t)0, 0, NCUCKOO);

        // count number of even end point
        for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
          {
            int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
            int size = (edges + WIDTH - 1) / WIDTH;
            //alive->read(alive_cache, n / WIDTH, size);
            memory_read_accel(alive, alive_cache, n / WIDTH, size);

            for (int i = 0; i < size; i++)
              {
                mem_t live_word = alive_cache[i];

                for (int j = 0; j < WIDTH; j++)
                  {
                    int k = i * WIDTH + j;

                    if (k >= edges)
                      break;

                    bool live = (live_word >> j) & 1;

                    if (live)
                      {
                        uint8_t count;
                        // int e = round % 2 == 0 ? evenNode(n + k) : oddNode(n + k);
                        int e =  round % 2 == 0 ? evenNode(n + k, sip_keys) : oddNode(n + k, sip_keys);
                        // trim->read(&count, e);
                        count = trim[e];
                        count = count < 2 ? count + 1 : count;
                        // trim->write(&count, e);
                        trim[e] = count;
                      }
                  }
              }
          }

// trim leaf
        trimed = 0;
        remain = 0;

        for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
          {
            int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
            int size = (edges + WIDTH - 1) / WIDTH;
            // alive->read(alive_cache, n / WIDTH, size);
            memory_read_accel(alive, alive_cache, n / WIDTH, size);

            for (int i = 0; i < size; i++)
              {
                mem_t live_word = alive_cache[i];

                for (int j = 0; j < WIDTH; j++)
                  {
                    int k = i * WIDTH + j;

                    if (k >= edges)
                      break;

                    bool live = (live_word >> j) & 1;

                    if (live)
                      {
                        uint8_t count;
                        //int e =  round % 2 == 0 ? evenNode(n + k) : oddNode(n + k);
                        int e =  round % 2 == 0 ? evenNode(n + k, sip_keys) : oddNode(n + k, sip_keys);
                        // trim->read(&count, e);
                        count = trim[e];

                        if (count < 2)
                          {
                            live_word &= ~((mem_t)1 << j);
                            trimed++;
                          }
                        else
                          remain++;
                      }
                  }

                alive_cache[i] = live_word;
              }

            memory_write_accel(alive_cache, alive, n / WIDTH, size);
            //alive->write(alive_cache, n / WIDTH, size);
          }
      }

// remains write
    nRemains = 0;
    uint32_t block = 0;

    for (int n = 0; n < easiness; n += ALIVE_CACHE_EDGES)
      {
        int edges = easiness - n > ALIVE_CACHE_EDGES ? ALIVE_CACHE_EDGES : easiness - n;
        int size = (edges + WIDTH - 1) / WIDTH;
        // alive->read(alive_cache, n / WIDTH, size);
        memory_read_accel(alive, alive_cache, n / WIDTH, size);

        for (int i = 0; i < size; i++)
          {
            mem_t live_word = alive_cache[i];

            for (int j = 0; j < WIDTH; j++)
              {
                int k = i * WIDTH + j;

                if (k >= edges)
                  break;

                bool live = (live_word >> j) & 1;

                if (live)
                  {
                    uint32_t e = n + k;

                    //remains->write(&e, nRemains++);
                    if (nRemains == REMAINS_CACHE_SIZE)
                      {
                        memory_write_accel(remains_buffer, remains, block * REMAINS_CACHE_SIZE, REMAINS_CACHE_SIZE);
                        nRemains = 0;
                        block = block + 1;
                      }

                    // std::cout<<"nRemains is "<< nRemains<<" Block is "<<block<<std::endl;
                    remains_buffer[nRemains++] = e;
//                  if (nRemains == remain)
//                    break;
                  }
              }
          }
      }

// ************************* data output **************************************
    n_remains[0] = remain;
    memory_write_accel(remains_buffer, remains, block * REMAINS_CACHE_SIZE, nRemains);
//    loop_write_remains:
//  for(int i=0;i <MAX_REMAINS; i++)
//     remains[i] = remains_buffer[i];
  }

}
// ************************* function from memory.h ***************************
template <typename DataType>
void memory_set_accel(DataType* mem, DataType d, uint32_t addr, uint32_t len)
{
  for (int i = 0; i < len; i++)
    mem[addr + i] = d;
}
//memcpy (void *__restrict __dest, const void *__restrict __src
template <typename DataType>
void memory_read_accel(DataType* mem_src, DataType* mem_dst, uint32_t addr, uint32_t len)
{
  for (int i = 0; i < len; i++)
    mem_dst[i] = mem_src[addr + i];
}

template <typename DataType>
void memory_write_accel(DataType* mem_src, DataType* mem_dst, uint32_t addr, uint32_t len)
{
  for (int i = 0; i < len; i++)
    mem_dst[addr + i] = mem_src[i];
}
// ******************************* function from siphash.h ************************
// ********************************************************************************
void siphash_keys_accel::setkeys(const char* keybuf)
{
  k0 = htole64(((uint64_t*)keybuf)[0]);
  k1 = htole64(((uint64_t*)keybuf)[1]);
  k2 = htole64(((uint64_t*)keybuf)[2]);
  k3 = htole64(((uint64_t*)keybuf)[3]);
}

uint64_t siphash_keys_accel::siphash24(const uint64_t nonce) const
{
  siphash_state_accel<> v(*this);
  v.hash24(nonce);
  return v.xor_lanes();
}

// **************************** function from cuckoo.h ****************************
// ********************************************************************************
// generate edge endpoint in cuckoo graph without partition bit
word_t sipnode(siphash_keys_accel keys, word_t edge, u32 uorv)
{
  return (keys.siphash24(2 * edge + uorv)) & EDGEMASK;
}
// ******************************* function from pow.h ****************************
// ********************************************************************************
u32 oddNode(u32 n, siphash_keys_accel keys)
{
  return 2 * sipnode(keys, n, 1) + 1;
}

u32 evenNode(u32 n, siphash_keys_accel keys)
{
  return 2 * sipnode(keys, n, 0);
}
