#include "xcl2.hpp"
#include <algorithm>


#include "Trim.h"
#include "accel_graph.h"
using namespace std;
using namespace tensorchip;

static uint8_t trim[NCUCKOO];
static mem_t alive[EASINESS + WIDTH - 1 / WIDTH];

int main(int argc, char** argv)
{
  if (argc != 2)
    {
      std::cout << "Usage: " << argv[0] << " <XCLBIN File>" << std::endl;
      return EXIT_FAILURE;
    }

  cout << "EDGEBITS = " << EDGEBITS << endl;
  u32 nonce = 0;
// for cpu compute
  char header_sw[HEADERLEN];
  memset(header_sw, 0, HEADERLEN);
  Trim* pow = new Trim(header_sw, EASIPCT);
  int easiness = EASINESS;
  // hw prepare
  int n_remains[1] = {easiness};
  uint64_t siphash_keys[4];
  memset(siphash_keys, 0, 32);
  memset(trim, 0, NCUCKOO * sizeof(uint8_t));
  cout << "trim init and NCUCKOO=" << NCUCKOO << endl;
  cout << "easiness=" << easiness << endl;
  uint32_t* remains = new uint32_t[MAX_REMAINS];
  memset(remains, 0, MAX_REMAINS * sizeof(uint32_t));
  cout << "remains init and MAX_REMAINS=" << MAX_REMAINS << endl;
  cout << "start software reset" << endl;
  pow->reset(nonce);
  siphash_keys[0] = pow->sip_keys.k0;
  siphash_keys[1] = pow->sip_keys.k1;
  siphash_keys[2] = pow->sip_keys.k2;
  siphash_keys[3] = pow->sip_keys.k3;
  cout << "sip keys assignment and start run" << endl;
  std::string binaryFile = argv[1];
  cl_int err;
  // OPENCL HOST CODE AREA START
  auto devices = xcl::get_xil_devices();
  auto device = devices[0];
  OCL_CHECK(err, cl::Context context(device, NULL, NULL, NULL, &err));
  OCL_CHECK(
    err,
    cl::CommandQueue q(context, device, CL_QUEUE_PROFILING_ENABLE, &err));
  // read_binary_file() is a utility API which will load the binaryFile
  auto fileBuf = xcl::read_binary_file(binaryFile);
  cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
  devices.resize(1);
  OCL_CHECK(err, cl::Program program(context, devices, bins, NULL, &err));
  // Allocate Buffer in Global Memory
  cout << "****** Allocate Buffer in Global Memory ******" << endl;
  OCL_CHECK(err,
            cl::Buffer buffer_alive(context,
                                    CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                    sizeof(mem_t) * (easiness + 7) / 8,
                                    alive,
                                    &err));
  OCL_CHECK(err,
            cl::Buffer buffer_remains(context,
                                      CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                      MAX_REMAINS * sizeof(uint32_t),
                                      remains,
                                      &err));
  OCL_CHECK(err,
            cl::Buffer buffer_keys(context,
                                   CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                   4 * sizeof(uint64_t),
                                   siphash_keys,
                                   &err));
  OCL_CHECK(err,
            cl::Buffer buffer_trim(context,
                                   CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                   NCUCKOO * sizeof(uint8_t),
                                   trim,
                                   &err));
  OCL_CHECK(err,
            cl::Buffer buffer_n_remains(context,
                                        CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY,
                                        1 * sizeof(int),
                                        n_remains,
                                        &err));
  cout << "****** kernel args set ******" << endl;
  OCL_CHECK(err, cl::Kernel krnl_graph_accel(program, "graph_accel", &err));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(0, buffer_alive));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(1, buffer_remains));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(2, buffer_keys));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(3, buffer_trim));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(4, easiness));
  OCL_CHECK(err, err = krnl_graph_accel.setArg(5, buffer_n_remains));
  // Copy input data to device global memory
  cout << "****** copy input data to device global memory ******" << endl;
  auto start = chrono::system_clock::now();
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({buffer_keys},
                  0 /* 0 means from host*/));
  // Launch the Kernel
  cout << "****** Launch the Kernel ******" << endl;
  OCL_CHECK(err, err = q.enqueueTask(krnl_graph_accel));
  // Copy Result from Device Global Memory to Host Local Memory
  cout << "****** Copy Result from Device Global Memory to Host Local Memory ******" << endl;
  OCL_CHECK(err,
            err = q.enqueueMigrateMemObjects({/*buffer_alive, */buffer_remains, /*buffer_trim, */buffer_n_remains},
                  CL_MIGRATE_MEM_OBJECT_HOST));
  cout << "****** prepare finishing the kernel ******" << endl;
  OCL_CHECK(err, err = q.finish());
  auto end = chrono::system_clock::now();
  std::chrono::duration<double> diff = end - start;
  cout << "Time elipsed in Device is " << diff.count() << endl;
  // OPENCL HOST CODE AREA END
  cout << "****** prepare cpu running ******" << endl;
  pow->run();
  cout << "finish running" << endl;
  // Compare the results of the Device to the simulation
  std::cout << "**************** start graph function validation ***************" << std::endl;
  cout << "number of edge remains is " << n_remains[0] << endl;
  bool match_remains = true;

  for (int i = 0; i < n_remains[0]; i++)
    {
      if ((pow->remains->mem)[i] != remains[i])
        {
          std::cout << "Error: Remains ";
          std::cout << "i = " << i << " CPU result = " << (pow->remains->mem)[i]
                    << " Device result = " << remains[i]
                    << std::endl;
          match_remains = false;
          break;
        }

//      else
//        {
//          std::cout << "Success: Remains ";
//          std::cout << "i = " << i << " CPU result = " << (pow->remains->mem)[i]
//                    << " Device result = " << remains[i]
//                    << std::endl;
//        }
    }

  std::cout << "remains test " << (match_remains ? "PASSED" : "FAILED") << std::endl;
  bool match_trim = true;
//  for (int i = 0; i < (int)NCUCKOO; i++)
//    {
//      if ((pow->trim->mem)[i] != trim[i])
//        {
//          std::cout << "Error: trim ";
//          std::cout << "i = " << i << " CPU result = " << (pow->trim->mem)[i]
//                    << " Device result = " << trim[i]
//                    << std::endl;
//          match_trim = false;
//          break;
//        }
////      else
////        {
////          std::cout << "Success: trim ";
////          std::cout << "i = " << i << " CPU result = " << (pow->trim->mem)[i]
////                    << " Device result = " << trim[i]
////                    << std::endl;
////        }
//    }
//
//  std::cout << "trim test " << (match_trim ? "PASSED" : "FAILED") << std::endl;
//
  bool match_alive = true;
//  for (int i = 0; i < (int)(easiness + 7) / 8; i++)
//    {
//
//      if ((pow->alive->mem)[i] != alive[i])
//        {
//          std::cout << "Error: alive ";
//          std::cout << "i = " << i << " CPU result = " << (pow->alive->mem)[i]
//                    << " Device result = " << alive[i]
//                    << std::endl;
//          match_alive = false;
//          break;
//        }
////      else
////        {
////          std::cout << "Success: alive ";
////          std::cout << "i = " << i << " CPU result = " << (pow->alive->mem)[i]
////                    << " Device result = " << alive[i]
////                    << std::endl;
////        }
//    }
//
//  std::cout << "alive test " << (match_alive ? "PASSED" : "FAILED") << std::endl;
  std::cout << " ****** Graph Test " << ((match_remains & match_trim & match_alive) ? "PASSED" : "FAILED") << " ******" <<
            std::endl;
  return ((match_remains & match_trim & match_alive) ? EXIT_SUCCESS : EXIT_FAILURE);
}


