#ifndef _ACCEL_GRAPH_H_
#define _ACCEL_GRAPH_H_

#include <ap_int.h>                   // int1 to replace bool
#include "macro_accel.h"
#include "crypto/portable_endian.h"    // for htole32/64
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include <stddef.h>
#include <ap_int.h>
#include <iostream>

typedef ap_uint<1> uint1;

template <typename DataType>
void memory_set_accel(DataType* mem, DataType d, uint32_t addr, uint32_t len = 1);

template <typename DataType>
void memory_read_accel(DataType* mem_src, DataType* mem_dst, uint32_t addr, uint32_t len);

template <typename DataType>
void memory_write_accel(DataType* mem_src, DataType* mem_dst, uint32_t addr, uint32_t len);
// ************************ class definition from siphash.h ************************
// *********************************************************************************
// generalize siphash by using a quadruple of 64-bit keys,
class siphash_keys_accel
{
public:
  uint64_t k0;
  uint64_t k1;
  uint64_t k2;
  uint64_t k3;

  void setkeys(const char* keybuf);

  uint64_t siphash24(const uint64_t nonce) const;
};

template <int rotE = 21>
class siphash_state_accel
{
public:
  uint64_t v0;
  uint64_t v1;
  uint64_t v2;
  uint64_t v3;

  siphash_state_accel(const siphash_keys_accel& sk)
  {
    v0 = sk.k0;
    v1 = sk.k1;
    v2 = sk.k2;
    v3 = sk.k3;
  }
  uint64_t xor_lanes()
  {
    return (v0 ^ v1) ^ (v2  ^ v3);
  }
  void xor_with(const siphash_state_accel& x)
  {
    v0 ^= x.v0;
    v1 ^= x.v1;
    v2 ^= x.v2;
    v3 ^= x.v3;
  }
  static uint64_t rotl(uint64_t x, uint64_t b)
  {
    return (x << b) | (x >> (64 - b));
  }
  void sip_round()
  {
    v0 += v1;
    v2 += v3;
    v1 = rotl(v1, 13);
    v3 = rotl(v3, 16);
    v1 ^= v0;
    v3 ^= v2;
    v0 = rotl(v0, 32);
    v2 += v1;
    v0 += v3;
    v1 = rotl(v1, 17);
    v3 = rotl(v3, rotE);
    v1 ^= v2;
    v3 ^= v0;
    v2 = rotl(v2, 32);
  }
  void hash24(const uint64_t nonce)
  {
    v3 ^= nonce;
    sip_round();
    sip_round();
    v0 ^= nonce;
    v2 ^= 0xff;
    sip_round();
    sip_round();
    sip_round();
    sip_round();
  }
};

// **************************** function from cuckoo.h ****************************
// ********************************************************************************
// generate edge endpoint in cuckoo graph without partition bit
word_t sipnode(siphash_keys_accel keys, word_t edge, u32 uorv);
// ******************************* function from pow.h ****************************
// ********************************************************************************
u32 oddNode(u32 n, siphash_keys_accel keys);

u32 evenNode(u32 n, siphash_keys_accel keys);
#endif
