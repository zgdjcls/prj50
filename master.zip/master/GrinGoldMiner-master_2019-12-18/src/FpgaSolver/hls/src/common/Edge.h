#ifndef _EDGE_H_
#define _EDGE_H_
#include "cuckoo/cuckoo.h"
#include <string>
#include <sstream>
#include "macro_accel.h"
using namespace std;
namespace tensorchip
{
class Edge
{
public:
  Edge() : u(0), v(0) {}
  Edge(u32 x, u32 y) : u(x), v(y) {}

  u32 u, v;

  string toString()
  {
    stringstream ss;
    ss << fixed << "Edge \t: ( " << u << " -> " << v << " )" << endl;
    return ss.str();
  }
};
};

#endif
