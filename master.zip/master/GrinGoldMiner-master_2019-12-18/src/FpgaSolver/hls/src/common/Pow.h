#ifndef _POW_H_
#define _POW_H_

#define HEADERLEN 80
#define NNODES (2*NEDGES)
#include "Log.h"
#include "Edge.h"
#include "Path.h"
#include "cuckoo/cuckoo.h"
#include <iostream>
#include <vector>
using namespace std;


namespace tensorchip
{
class Pow
{
public:
  Pow(char* header, int easipct = 50);
  virtual void set_keys(u64 k0, u64 k1, u64 k2, u64 k3);
  virtual void reset(u32 nonce);
  virtual void graph() = 0;
  virtual void cycle() = 0;
  virtual void report() = 0;
  virtual int run();
  int numberOfEdges();
  virtual u32 getSolution(u32* nonces);


  Edge edge(u32 n);
  u32 oddNode(u32 n);
  u32 evenNode(u32 n);
  Path genSolution(Path cycle);
  void addSolution(Path solution);
  int verify(Path solution);

  char header[HEADERLEN];
  vector<Path> solutions;
  u32 nonce;
  int easipct;
  int easiness;
  siphash_keys sip_keys;

};
};

#endif
