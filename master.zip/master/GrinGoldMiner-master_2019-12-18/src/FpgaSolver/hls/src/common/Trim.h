#ifndef _POW_SIMPLE_H_
#define _POW_SIMPLE_H_
#include "Pow.h"
#include "Path.h"
#include "Memory.h"

#define NCUCKOO NNODES
#ifndef MAX_REMAINS_BITS
#define MAX_REMAINS_BITS 10
#endif
#define MAX_REMAINS (1<<MAX_REMAINS_BITS)

#if MAX_REMAINS_BITS >= 15
typedef uint32_t remain_t;
#else
typedef uint16_t remain_t;
#endif


namespace tensorchip
{
class Trim : public Pow
{
public:
  Trim(char* header, int easipct = 50);
  ~Trim();
  void reset(u32 nonce);
  void graph();
  void cycle();
  void report();

//private:
  Memory < remain_t, MAX_REMAINS_BITS + 1 > * cuckoo = nullptr;
  Memory<bool, 1>* alive = nullptr;
  Memory<uint8_t, 2>* trim = nullptr;
  Memory < remain_t, MAX_REMAINS_BITS + 1 > * index = nullptr;
  Memory < word_t, sizeof(word_t) * 8 >* map = nullptr;
  Memory<uint32_t, 32>* remains = nullptr;
  uint32_t nRemains = 0;
  Path path(remain_t node);
  Path genCycle(Path pu, Path pv);
  void genIndex();

};
};

#endif
