#include "Path.h"
#include "Log.h"
#include <assert.h>

namespace tensorchip
{
void Path::add(u32 node)
{
#ifdef VECTOR
  path.push_back(node);
#else
  path[len++] = node;
#endif
}

u32 Path::tail()
{
#ifdef VECTOR
  return path.back();
#else
  return path[len - 1];
#endif
}

int Path::size()
{
#ifdef VECTOR
  return path.size();
#else
  return len;
#endif
}

u32 Path::value(int i)
{
#ifdef VECTOR
  return path.at(i);
#else
  return path[i];
#endif
}

bool Path::find(Edge e)
{
  assert(size() % 2 == 0);
  int start = value(0) % 2 == 0 ? 0 : 1;
  int i = start;

  do
    {
      int left = (i + size() - 1) % size();
      int right = (i + 1) % size();

      if (value(i) == e.u && (value(left) == e.v || value(right) == e.v))
        return true;

      i = (i + 2) % size();
    }
  while (i != start);

  return false;
}

string Path::toString()
{
  stringstream ss;
  ss << hex << "Path : ";
#ifdef VECTOR

  for (vector<u32>::iterator it = path.begin(); it != path.end(); ++it)
    ss << *it << "->";

#else

  for (int i = 0; i < len; i++)
    ss << path[i] << "->";

#endif
  ss << endl;
  return ss.str();
}

};
