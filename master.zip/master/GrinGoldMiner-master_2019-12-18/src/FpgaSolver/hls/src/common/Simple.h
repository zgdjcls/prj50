#ifndef _POW_SIMPLE_H_
#define _POW_SIMPLE_H_
#include "Pow.h"
#include "Memory.h"
#include "Path.h"
#include "macro_accel.h"
#define NCUCKOO NNODES

namespace tensorchip
{
class Simple : public Pow
{
public:
  Simple(char* header, int easipct = 50);
  ~Simple();
  void reset(u32 nonce);
  void graph();
  void cycle();
  void report();

private:
  Memory<word_t, 32>* cuckoo = nullptr;
  Path path(u32 node);
  Path genCycle(Path pu, Path pv);

};
};

#endif
