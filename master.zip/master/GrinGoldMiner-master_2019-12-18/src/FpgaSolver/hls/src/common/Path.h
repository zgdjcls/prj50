#ifndef _PATH_H_
#define _PATH_H_
#include "Edge.h"
#include "cuckoo/cuckoo.h"
#include <string>
#include <sstream>
//#define VECTOR
#include "macro_accel.h"
#ifdef VECTOR
#include <vector>
#else
#define MAXPATHLEN (16 << (EDGEBITS/3))
#endif

using namespace std;
namespace tensorchip
{
class Path
{
public:
  void add(u32 node);
  u32 tail();
  int size();
  u32 value(int i);

  bool find(Edge e);
  string toString();
private:
#ifdef VECTOR
  vector<u32> path;
#else
  u32 path[MAXPATHLEN];
  int len = 0;
#endif
};
};

#endif
