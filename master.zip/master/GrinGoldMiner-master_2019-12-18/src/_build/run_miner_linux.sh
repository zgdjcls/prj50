#!/bin/sh

cd bin
export LD_LIBRARY_PATH=`pwd`
./GrinGoldMiner3
