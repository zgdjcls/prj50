#!/bin/sh

mkdir bin
cd ..
cd GrinGoldMiner3
dotnet publish -c Release -r linux-x64 --self-contained --framework netcoreapp2.2 --output ../_build/bin
cd ..
cd CudaSolver
dotnet publish -c Release -r linux-x64 --self-contained --framework netcoreapp2.2 --output ../_build/bin
cd ..
cd OclSolver
dotnet publish -c Release -r linux-x64 --self-contained --framework netcoreapp2.2 --output ../_build/bin
cd ..
cd CpuSolver
mkdir -p build && cd build && cmake .. && make CpuSolver && cp -f bin/CpuSolver ../../_build/bin/CpuSolver && cp -f lib/libpow.so ../../_build/bin/libpow.so
