#!/bin/sh

cd bin
./GrinGoldMinerAPI
